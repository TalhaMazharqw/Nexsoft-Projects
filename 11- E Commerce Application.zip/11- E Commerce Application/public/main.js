// Local application active tracking elements
let cartState = [];
let localFetchedProducts = []; 

// Identify active views routing endpoints
const isStorefront = document.getElementById('shop-products-grid') !== null;
const isDashboard = document.getElementById('admin-inventory-table-body') !== null;

document.addEventListener('DOMContentLoaded', () => {
    if (isStorefront) {
        initStorefront();
    }
    if (isDashboard) {
        initDashboard();
    }
});

/* ==========================================================================
   CUSTOMER STOREFRONT INTERACTION COMPONENT
   ========================================================================== */
function initStorefront() {
    const cartToggle = document.getElementById('cart-toggle-btn');
    const cartClose = document.getElementById('cart-close-btn');
    const cartDrawer = document.getElementById('cart-drawer');
    const cartBackdrop = document.getElementById('cart-backdrop');
    const checkoutBtn = document.getElementById('checkout-btn');
    const checkoutForm = document.getElementById('checkout-form');
    const shopNavLink = document.getElementById('nav-shop-link');
    const brandLogo = document.getElementById('nav-brand-logo');

    // Drawer Interface Hooks
    cartToggle.addEventListener('click', () => toggleCartDrawer(true));
    cartClose.addEventListener('click', () => toggleCartDrawer(false));
    cartBackdrop.addEventListener('click', () => toggleCartDrawer(false));

    // Move layout node layers to Checkout View
    checkoutBtn.addEventListener('click', () => {
        if (cartState.length === 0) {
            alert("Your shopping cart is currently empty!");
            return;
        }
        toggleCartDrawer(false);
        switchView('checkout-section');
    });

    // Capture payment and forward to Confirmation Screen
    checkoutForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Generate dynamic serial code string
        const generatedId = Math.floor(100000 + Math.random() * 900000);
        document.getElementById('dynamic-order-id').innerText = `#SC-${generatedId}`;

        // Reset memory matrices loops
        cartState = [];
        updateCartUi();
        checkoutForm.reset();
        switchView('confirmation-section');
    });

    // Navigation fallback anchors
    if(shopNavLink) shopNavLink.addEventListener('click', (e) => { e.preventDefault(); returnToCatalog(); });
    if(brandLogo) brandLogo.addEventListener('click', (e) => { e.preventDefault(); returnToCatalog(); });

    function toggleCartDrawer(open) {
        if (open) {
            cartDrawer.classList.add('open');
            cartBackdrop.classList.add('open');
        } else {
            cartDrawer.classList.remove('open');
            cartBackdrop.classList.remove('open');
        }
    }

    fetchCatalog();
}

async function fetchCatalog() {
    const grid = document.getElementById('shop-products-grid');
    try {
        const response = await fetch('/api/products');
        localFetchedProducts = await response.json();

        if (localFetchedProducts.length === 0) {
            grid.innerHTML = `
                <div class="grid-loading-placeholder">
                    <i class="fa-solid fa-box-open" style="font-size: 2.5rem; margin-bottom:12px; color:var(--text-soft);"></i>
                    <p>The shop shelves are empty! Head over to the Admin Panel to create products.</p>
                </div>`;
            return;
        }

        grid.innerHTML = ''; 
        localFetchedProducts.forEach(item => {
            const card = document.createElement('div');
            card.classList.add('product-card');
            card.innerHTML = `
                <div class="img-frame clickable-trigger" onclick="openProductModal('${item.id}')">
                    <span class="category-tag">${item.category}</span>
                    <img src="${item.imageUrl}" alt="${item.title}" onerror="this.src='https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=500'">
                </div>
                <div class="card-details">
                    <h4 class="clickable-trigger" onclick="openProductModal('${item.id}')">${item.title}</h4>
                    <div class="price-row">
                        <span class="price-lbl">$${parseFloat(item.price).toFixed(2)}</span>
                        <button class="add-cart-btn" onclick="addToCart(event, '${item.id}', '${escapeHtml(item.title)}', ${item.price}, '${item.imageUrl}')">
                            Add to Cart <i class="fa-solid fa-plus"></i>
                        </button>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
    } catch (err) {
        grid.innerHTML = `<div class="grid-loading-placeholder" style="color:var(--accent-red);"><i class="fa-solid fa-triangle-exclamation"></i> Problem connecting to API server database files.</div>`;
    }
}

function switchView(targetId) {
    const panels = ['main-store-section', 'checkout-section', 'confirmation-section'];
    panels.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            if (id === targetId) el.classList.remove('hidden-view');
            else el.classList.add('hidden-view');
        }
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

window.returnToCatalog = () => {
    switchView('main-store-section');
};

/* Product Details View Overlay Functions */
window.openProductModal = (id) => {
    const targetItem = localFetchedProducts.find(item => item.id === id);
    if (!targetItem) return;

    document.getElementById('modal-product-img').src = targetItem.imageUrl;
    document.getElementById('modal-product-category').innerText = targetItem.category;
    document.getElementById('modal-product-title').innerText = targetItem.title;
    document.getElementById('modal-product-price').innerText = `$${parseFloat(targetItem.price).toFixed(2)}`;

    const modalBtn = document.getElementById('modal-add-to-cart-btn');
    modalBtn.onclick = () => {
        executeCartAddition(targetItem.id, targetItem.title, targetItem.price, targetItem.imageUrl);
        closeProductModal();
    };

    document.getElementById('product-modal').classList.add('open');
};

window.closeProductModal = () => {
    document.getElementById('product-modal').classList.remove('open');
};

// Global intercept routes proxy tracking logic
window.addToCart = (event, id, title, price, imageUrl) => {
    event.stopPropagation(); // Avoid triggering openProductModal bounding layers
    executeCartAddition(id, title, price, imageUrl);
};

function executeCartAddition(id, title, price, imageUrl) {
    const existingIndex = cartState.findIndex(entry => entry.id === id);
    if (existingIndex > -1) {
        cartState[existingIndex].quantity += 1;
    } else {
        cartState.push({ id, title, price, imageUrl, quantity: 1 });
    }
    updateCartUi();
    document.getElementById('cart-drawer').classList.add('open');
    document.getElementById('cart-backdrop').classList.add('open');
}

function updateCartUi() {
    const badge = document.getElementById('cart-count-badge');
    const box = document.getElementById('cart-items-container');
    const subtotalDisplay = document.getElementById('cart-subtotal-val');

    const totalItemsCount = cartState.reduce((acc, current) => acc + current.quantity, 0);
    const cumulativeTotalPrice = cartState.reduce((acc, current) => acc + (current.price * current.quantity), 0);

    badge.innerText = totalItemsCount;
    subtotalDisplay.innerText = `$${cumulativeTotalPrice.toFixed(2)}`;

    if (cartState.length === 0) {
        box.innerHTML = `<p style="color:var(--text-soft); text-align:center; padding-top:40px; font-weight:500;">Your cart is completely empty.</p>`;
        return;
    }

    box.innerHTML = '';
    cartState.forEach(row => {
        const rowNode = document.createElement('div');
        rowNode.classList.add('cart-line-item');
        rowNode.innerHTML = `
            <img src="${row.imageUrl}" alt="" onerror="this.src='https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=500'">
            <div class="item-meta">
                <h5>${row.title}</h5>
                <span>$${row.price.toFixed(2)} × ${row.quantity}</span>
            </div>
            <button class="remove-item-btn" onclick="removeFromCart('${row.id}')" aria-label="Drop item">
                <i class="fa-solid fa-trash-can"></i>
            </button>
        `;
        box.appendChild(rowNode);
    });
}

window.removeFromCart = (id) => {
    cartState = cartState.filter(item => item.id !== id);
    updateCartUi();
};

/* ==========================================================================
   ADMINISTRATIVE CONTROL DASHBOARD MANAGEMENT
   ========================================================================== */
function initDashboard() {
    const uploadForm = document.getElementById('product-upload-form');
    
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const packageData = {
            title: document.getElementById('prod-name').value.trim(),
            price: parseFloat(document.getElementById('prod-price').value),
            category: document.getElementById('prod-category').value,
            imageUrl: document.getElementById('prod-image').value.trim()
        };

        try {
            const res = await fetch('/api/products', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(packageData)
            });

            if (res.ok) {
                uploadForm.reset();
                fetchAdminInventory();
            }
        } catch (err) {
            alert("Could not append item to runtime storage database maps.");
        }
    });

    fetchAdminInventory();
}

async function fetchAdminInventory() {
    const tbody = document.getElementById('admin-inventory-table-body');
    if (!tbody) return;

    try {
        const response = await fetch('/api/products');
        const items = await response.json();

        if (items.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center" style="color:var(--text-soft); padding: 32px; font-weight:500;">No product history catalog files found.</td></tr>`;
            return;
        }

        tbody.innerHTML = '';
        items.forEach(product => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><img class="table-thumb" src="${product.imageUrl}" alt="" onerror="this.src='https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=500'"></td>
                <td><strong>${product.title}</strong></td>
                <td><span class="category-tag" style="position:static; display:inline-block;">${product.category}</span></td>
                <td><strong>$${parseFloat(product.price).toFixed(2)}</strong></td>
                <td>
                    <button class="trash-btn" onclick="deleteProduct('${product.id}')" title="Remove Listing">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center" style="color:var(--accent-red);">Failed loading items catalog streams.</td></tr>`;
    }
}

window.deleteProduct = async (id) => {
    if (!confirm("Are you sure you want to delete this listing from your database?")) return;
    try {
        const response = await fetch(`/api/products/${id}`, { method: 'DELETE' });
        if (response.ok) {
            fetchAdminInventory();
        }
    } catch (err) {
        alert("Server transmission failure during catalog entry deletion.");
    }
};

function escapeHtml(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}