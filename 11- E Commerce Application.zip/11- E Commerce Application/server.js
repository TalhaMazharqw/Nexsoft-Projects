const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 4000;

// Middleware parsed processing loops
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Mock In-Memory Database Matrix Array
let productDatabase = [
    {
        id: "prod-101",
        title: "Cyberpunk Mechanical Keyboard",
        price: 129.99,
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=500"
    },
    {
        id: "prod-102",
        title: "Sleek Matte Tech Organizer Pack",
        price: 45.00,
        category: "Gear",
        imageUrl: "https://images.unsplash.com/photo-1625225233840-6954c0e4198a?w=500"
    }
];

/* ==========================================================================
   REST API DATABASE ROUTES
   ========================================================================== */

// 1. GET: Read complete array inventory listings
app.get('/api/products', (req, res) => {
    res.json(productDatabase);
});

// 2. POST: Create and insert a new object profile listing
app.post('/api/products', (req, res) => {
    const { title, price, category, imageUrl } = req.body;
    
    if (!title || !price || !imageUrl) {
        return res.status(400).json({ error: "Missing product fields parameters values." });
    }

    const newProduct = {
        id: `prod-${Date.now()}`, // Dynamic unique timestamp signature hash strings
        title,
        price: parseFloat(price),
        category: category || "General",
        imageUrl
    };

    productDatabase.push(newProduct);
    console.log(`Inventory Add: ${title}`);
    res.status(21).json(newProduct);
});

// 3. DELETE: Target deletion drop loops by targeting individual ID queries
app.delete('/api/products/:id', (req, res) => {
    const targetId = req.params.id;
    const initialLength = productDatabase.length;
    
    productDatabase = productDatabase.filter(item => item.id !== targetId);
    
    if (productDatabase.length === initialLength) {
        return res.status(404).json({ error: "Item not found match in collection records." });
    }

    console.log(`Inventory Delete ID: ${targetId}`);
    res.json({ success: true, message: "Inventory record dropped." });
});

// Start listening loops on network stack
app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`SwiftCart Webserver is operating live on: http://localhost:${PORT}`);
    console.log(`=======================================================`);
});