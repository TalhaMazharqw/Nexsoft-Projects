/**
 * Nexus SaaS Landing Page Interaction Logic
 */

// ── Mobile Navigation Menu Toggle ───────────────────
document.getElementById('hamburger').addEventListener('click', () => {
    document.getElementById('navLinks').classList.toggle('open');
  });
  
  // ── Scroll Reveal Intersection Observer ─────────────
  // Animates cards dynamically into viewport focus with a staggered timeline
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        
        // Calculate and inject incremental staggered delay for adjacent cards
        const siblings = entry.target.parentElement.querySelectorAll('.reveal');
        siblings.forEach((el, index) => {
          el.style.transitionDelay = (index * 0.08) + 's';
        });
        
        // Unobserve target element once transition is executed
        revealObserver.unobserve(entry.target);
      }
    });
  }, { 
    threshold: 0.1, 
    rootMargin: '0px 0px -40px 0px' 
  });
  
  // Bind animation watch triggers across card elements
  document.querySelectorAll('.reveal').forEach((el) => {
    revealObserver.observe(el);
  });
  
  // ── Sticky Navigation Highlight Border ──────────────
  window.addEventListener('scroll', () => {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 10) {
      navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.06)';
    } else {
      navbar.style.boxShadow = 'none';
    }
  });