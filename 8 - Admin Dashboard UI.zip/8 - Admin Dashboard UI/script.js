// ==========================================
// DATA SCHEMAS FOR REUSABLE COMPONENT GENERATION
// ==========================================

const navigationLinksSchema = [
    { title: "Dashboard Overview", iconClass: "fa-chart-line", viewId: "view-overview", active: true },
    { title: "Database Architecture", iconClass: "fa-database", viewId: "view-database" },
    { title: "Identity Security Matrix", iconClass: "fa-fingerprint", viewId: "view-security" },
    { title: "API Payload Control", iconClass: "fa-network-wired", viewId: "view-api" },
    { title: "System Configuration", iconClass: "fa-sliders", viewId: "view-settings" }
];

const metricsCardsSchema = [
    { label: "Active Nodes", value: "3,812", indicator: "+18.4%", trendUp: true, iconClass: "fa-server", bgGlow: "rgba(37, 99, 235, 0.15)", iconColor: "#2563eb" },
    { label: "Auth Requests", value: "89.4k", indicator: "+4.2%", trendUp: true, iconClass: "fa-key", bgGlow: "rgba(22, 163, 74, 0.15)", iconColor: "#16a34a" },
    { label: "System Load", value: "42.1%", indicator: "-3.1%", trendUp: false, iconClass: "fa-temperature-half", bgGlow: "rgba(234, 88, 12, 0.15)", iconColor: "#ea580c" },
    { label: "API Failure Weight", value: "0.02%", indicator: "0.0%", trendUp: true, iconClass: "fa-triangle-exclamation", bgGlow: "rgba(234, 88, 12, 0.15)", iconColor: "#ea580c" }
];

const logTableMatrixSchema = [
    { trkId: "#TRK-9021", process: "MongoDB Atlas Cloud Cluster Sync", status: "Active Stream", statusClass: "active", latency: "14.2ms", time: "Just Now" },
    { trkId: "#TRK-7741", process: "JSON Web Token Security Verification", status: "Active Stream", statusClass: "active", latency: "38.5ms", time: "2 mins ago" },
    { trkId: "#TRK-1094", process: "OMDb API Content Payload Hydration", status: "Throttled Queue", statusClass: "warning", latency: "214.0ms", time: "9 mins ago" }
];

// Global Chart References to support instant Theme Updates
let trafficLineChartInstance = null;
let databasePieChartInstance = null;

// ==========================================
// ⚙️ COMPONENT GENERATION CONTROLLERS
// ==========================================

function buildMenuLinkComponent(linkData) {
    return `
        <div class="menu-link-item ${linkData.active ? 'active' : ''}" data-view="${linkData.viewId}">
            <i class="fa-solid ${linkData.iconClass}"></i>
            <span>${linkData.title}</span>
        </div>
    `;
}

function buildMetricCardComponent(cardData) {
    return `
        <div class="metric-card-wrapper">
            <div class="card-data-pane">
                <h4>${cardData.label}</h4>
                <div style="display: flex; align-items: center;">
                    <span class="value-header">${cardData.value}</span>
                    <span class="trend-metric ${cardData.trendUp ? 'up' : 'down'}">${cardData.indicator}</span>
                </div>
            </div>
            <div class="card-icon-bounding" style="background-color: ${cardData.bgGlow}; color: ${cardData.iconColor};">
                <i class="fa-solid ${cardData.iconClass}"></i>
            </div>
        </div>
    `;
}

function buildTableRowComponent(rowElement) {
    return `
        <tr>
            <td style="font-family: monospace; font-weight: 700; color: var(--accent-blue);">${rowElement.trkId}</td>
            <td><strong>${rowElement.process}</strong></td>
            <td><span class="status-row-badge ${rowElement.statusClass}">${rowElement.status}</span></td>
            <td style="color: var(--text-muted); font-weight: 500;">${rowElement.latency}</td>
            <td style="color: var(--text-muted);">${rowElement.time}</td>
        </tr>
    `;
}

function compileDashboardComponents() {
    document.getElementById('dynamic-menu-target').innerHTML = navigationLinksSchema.map(buildMenuLinkComponent).join('');
    document.getElementById('metrics-cards-target').innerHTML = metricsCardsSchema.map(buildMetricCardComponent).join('');
    document.getElementById('dynamic-table-rows-target').innerHTML = logTableMatrixSchema.map(buildTableRowComponent).join('');
    
    attachNavigationListeners();
}

// ==========================================
// 🔄 INTERACTIVE VIEW NAVIGATION LOGIC (MAKE BUTTONS WORK)
// ==========================================
function attachNavigationListeners() {
    const menuButtons = document.querySelectorAll('.menu-link-item');
    const viewPanels = document.querySelectorAll('.dashboard-view-panel');
    const routeBreadcrumb = document.getElementById('route-title-breadcrumb');
    const sidebarNode = document.getElementById('sidebar-target');

    menuButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active rules from all menu nodes
            menuButtons.forEach(m => m.classList.remove('active'));
            btn.classList.add('active');

            // Toggle Visibility Classes Across View Frames
            const targetViewId = btn.getAttribute('data-view');
            viewPanels.forEach(panel => {
                if (panel.id === targetViewId) {
                    panel.classList.remove('hidden');
                } else {
                    panel.add('hidden'); // This ensures only the requested tab is rendered
                    panel.classList.add('hidden');
                }
            });

            // Update Breadcrumb Text dynamically
            routeBreadcrumb.innerText = btn.querySelector('span').innerText;

            // Auto-retract sidebar when operating on mobile/responsive formats
            sidebarNode.classList.remove('mobile-open');
        });
    });
}

// ==========================================
// 📊 DYNAMIC DATA GRID CHARTS ARCHITECTURE (CHART.JS)
// ==========================================
function renderAnalyticsCharts() {
    const isDarkMode = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDarkMode ? '#1e293b' : '#cbd5e1';
    const labelColor = isDarkMode ? '#94a3b8' : '#64748b';

    // Destruct previous line instance if re-initializing under dark configurations
    if (trafficLineChartInstance) trafficLineChartInstance.destroy();
    if (databasePieChartInstance) databasePieChartInstance.destroy();

    // 1. Line Chart Construction Engine
    const ctxLine = document.getElementById('trafficAnalyticsChart').getContext('2d');
    trafficLineChartInstance = new Chart(ctxLine, {
        type: 'line',
        data: {
            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
            datasets: [{
                label: 'Data Payload Vectors (MB)',
                data: [120, 310, 850, 1240, 980, 450],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: labelColor } } },
            scales: {
                x: { grid: { color: gridColor }, ticks: { color: labelColor } },
                y: { grid: { color: gridColor }, ticks: { color: labelColor } }
            }
        }
    });

    // 2. Pie Chart Construction Engine
    const ctxPie = document.getElementById('databaseDistributionChart').getContext('2d');
    databasePieChartInstance = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: ['MongoDB Atlas', 'Redis Cache', 'OMDb Wrapper'],
            datasets: [{
                data: [55, 25, 20],
                backgroundColor: ['#16a34a', '#3b82f6', '#ea580c'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { color: labelColor } } }
        }
    });
}

// ==========================================
// 🌗 DESIGN MODE & SIDEBAR BREAKPOINT HANDLERS
// ==========================================
const sidebarNode = document.getElementById('sidebar-target');
const openHamburger = document.getElementById('nav-open-toggle');
const closeDrawer = document.getElementById('nav-close-toggle');
const themeToggleBtn = document.getElementById('theme-mode-btn');

openHamburger.addEventListener('click', () => sidebarNode.classList.add('mobile-open'));
closeDrawer.addEventListener('click', () => sidebarNode.classList.remove('mobile-open'));

themeToggleBtn.addEventListener('click', () => {
    if (document.documentElement.getAttribute('data-theme') === 'dark') {
        document.documentElement.removeAttribute('data-theme');
        themeToggleBtn.innerHTML = `<i class="fa-solid fa-moon"></i>`;
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeToggleBtn.innerHTML = `<i class="fa-solid fa-sun"></i>`;
    }
    // Re-render charts immediately to swap grid axis label colors cleanly
    renderAnalyticsCharts();
});

// App Bootstrap execution initialization loop
window.addEventListener('DOMContentLoaded', () => {
    compileDashboardComponents();
    renderAnalyticsCharts();
});