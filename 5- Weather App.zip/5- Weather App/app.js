/**
 * Skye — Weather Application Functional Engine
 */

// ── Application Memory Cache Registers ──────────────
let recentCities = JSON.parse(localStorage.getItem('skyeRecent') || '[]');

// ── DOM References ──────────────────────────────────
const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const recentSearchesContainer = document.getElementById('recentSearches');
const spinner = document.getElementById('spinner');
const errorMsg = document.getElementById('errorMsg');
const hintState = document.getElementById('hintState');
const weatherCard = document.getElementById('weatherCard');

// ── Render Local History Ledger Tags ────────────────
function renderRecent() {
  recentSearchesContainer.innerHTML = recentCities.slice(0, 5).map(city => `
    <span class="recent-tag" data-city="${city}">${city}</span>
  `).join('');
}

// ── Append Query Entries into Storage ───────────────
function addRecent(city) {
  recentCities = [city, ...recentCities.filter(c => c.toLowerCase() !== city.toLowerCase())].slice(0, 5);
  localStorage.setItem('skyeRecent', JSON.stringify(recentCities));
  renderRecent();
}

// ── Intercept Layout Actions & Redirections ─────────
function searchCity(city) {
  cityInput.value = city;
  fetchWeather();
}

// ── Decode WMO Codes Mapping Matrix ─────────────────
function decodeWeather(code, isDay) {
  const night = !isDay;
  const map = {
    0:  { icon: night ? '🌙' : '☀️',  desc: 'Clear sky',         theme: night ? 'night' : 'clear' },
    1:  { icon: night ? '🌙' : '🌤️', desc: 'Mainly clear',       theme: night ? 'night' : 'clear' },
    2:  { icon: '⛅',                 desc: 'Partly cloudy',      theme: 'cloudy' },
    3:  { icon: '☁️',                desc: 'Overcast',            theme: 'cloudy' },
    45: { icon: '🌫️',               desc: 'Foggy',               theme: 'cloudy' },
    48: { icon: '🌫️',               desc: 'Icy fog',             theme: 'cloudy' },
    51: { icon: '🌦️',               desc: 'Light drizzle',       theme: 'rainy' },
    53: { icon: '🌦️',               desc: 'Moderate drizzle',    theme: 'rainy' },
    55: { icon: '🌧️',               desc: 'Dense drizzle',       theme: 'rainy' },
    61: { icon: '🌧️',               desc: 'Slight rain',         theme: 'rainy' },
    63: { icon: '🌧️',               desc: 'Moderate rain',       theme: 'rainy' },
    65: { icon: '🌧️',               desc: 'Heavy rain',          theme: 'rainy' },
    71: { icon: '🌨️',               desc: 'Light snow',          theme: 'snow' },
    73: { icon: '❄️',                desc: 'Moderate snow',       theme: 'snow' },
    75: { icon: '❄️',                desc: 'Heavy snow',          theme: 'snow' },
    80: { icon: '🌦️',               desc: 'Light showers',       theme: 'rainy' },
    81: { icon: '🌧️',               desc: 'Moderate showers',    theme: 'rainy' },
    82: { icon: '🌧️',               desc: 'Violent showers',     theme: 'rainy' },
    95: { icon: '⛈️',               desc: 'Thunderstorm',        theme: 'thunder' },
    96: { icon: '⛈️',               desc: 'Thunderstorm w/ hail',theme: 'thunder' },
    99: { icon: '⛈️',               desc: 'Heavy thunderstorm',  theme: 'thunder' },
  };
  return map[code] || { icon: '🌡️', desc: 'Unknown', theme: 'default' };
}

// ── Interface State Control Pipes ───────────────────
function showError(msg) {
  errorMsg.textContent = '⚠️ ' + msg;
  errorMsg.classList.add('visible');
}

function hideError() { 
  errorMsg.classList.remove('visible'); 
}

// ── Primary Async API Query Pipeline ────────────────
async function fetchWeather() {
  const queryValue = cityInput.value.trim();
  if (!queryValue) return;

  // Clear previous execution artifacts
  hideError();
  weatherCard.classList.remove('visible');
  hintState.style.display = 'none';
  spinner.classList.add('visible');

  try {
    // Step 1: Query Open-Meteo Geocoding API endpoint
    const geoRes = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(queryValue)}&count=1&language=en&format=json`
    );
    const geoData = await geoRes.json();

    if (!geoData.results || geoData.results.length === 0) {
      throw new Error(`City "${queryValue}" not found. Try a different spelling.`);
    }

    const { latitude, longitude, name, country, country_code } = geoData.results[0];

    // Step 2: Query Weather Metrics Forecast Matrix Channel
    const weatherRes = await fetch(
      `https://api.open-meteo.com/v1/forecast?` +
      `latitude=${latitude}&longitude=${longitude}` +
      `&current=temperature_2m,relative_humidity_2m,apparent_temperature,` +
      `weather_code,wind_speed_10m,visibility,uv_index,is_day` +
      `&daily=weather_code,temperature_2m_max,temperature_2m_min` +
      `&timezone=auto&forecast_days=7`
    );
    const data = await weatherRes.json();

    // Parse Response Payloads
    const curr = data.current;
    const daily = data.daily;
    const weather = decodeWeather(curr.weather_code, curr.is_day);

    // Apply Content into DOM Nodes
    document.getElementById('cityDisplay').textContent = name;
    document.getElementById('countryDisplay').textContent = `${country} ${getFlagEmoji(country_code)}`;
    document.getElementById('weatherIcon').textContent = weather.icon;
    document.getElementById('tempVal').textContent = Math.round(curr.temperature_2m);
    document.getElementById('conditionText').textContent = weather.desc;
    document.getElementById('feelsLike').textContent = `Feels like ${Math.round(curr.apparent_temperature)}°C`;

    document.getElementById('humidity').textContent = `${curr.relative_humidity_2m}%`;
    document.getElementById('wind').textContent = `${Math.round(curr.wind_speed_10m)} km/h`;
    document.getElementById('visibility').textContent = curr.visibility
      ? `${(curr.visibility / 1000).toFixed(1)} km`
      : 'N/A';
    document.getElementById('uvIndex').textContent = curr.uv_index !== undefined
      ? `${curr.uv_index} — ${uvLabel(curr.uv_index)}`
      : 'N/A';

    // Parse Timeline Data Arrays
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    document.getElementById('forecastRow').innerHTML = daily.time.map((date, i) => {
      const d = new Date(date);
      const wth = decodeWeather(daily.weather_code[i], true);
      const label = i === 0 ? 'Today' : days[d.getDay()];
      return `
        <div class="forecast-item">
          <span class="fc-day">${label}</span>
          <span class="fc-icon">${wth.icon}</span>
          <div class="fc-temps">
            <span class="fc-high">${Math.round(daily.temperature_2m_max[i])}°</span>
            <span class="fc-low">${Math.round(daily.temperature_2m_min[i])}°</span>
          </div>
        </div>
      `;
    }).join('');

    // Inject Dynamic Theme Blueprint
    document.body.className = `theme-${weather.theme}`;

    // Display Active Panel View
    spinner.classList.remove('visible');
    weatherCard.classList.add('visible');

    addRecent(name);

  } catch (err) {
    spinner.classList.remove('visible');
    showError(err.message || 'Failed to fetch weather. Please try again.');
    document.body.className = 'theme-default';
  }
}

// ── Auxiliary Conversions & Data Format Pipes ──────────
function uvLabel(uv) {
  if (uv <= 2)  return 'Low';
  if (uv <= 5)  return 'Moderate';
  if (uv <= 7)  return 'High';
  if (uv <= 10) return 'Very High';
  return 'Extreme';
}

function getFlagEmoji(code) {
  if (!code) return '';
  return code.toUpperCase().split('').map(c =>
    String.fromCodePoint(127397 + c.charCodeAt(0))
  ).join('');
}

// ── Application Unified Interface Listeners ───────────
searchBtn.addEventListener('click', fetchWeather);

cityInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') fetchWeather();
});

recentSearchesContainer.addEventListener('click', e => {
  if (e.target.classList.contains('recent-tag')) {
    const selectedCity = e.target.getAttribute('data-city');
    searchCity(selectedCity);
  }
});

// ── Engine Initialization Pipeline ───────────────────
renderRecent();