// Verification Interceptor Simulation Layer Architecture
// Uses explicit localStorage management variables acting as verified JWT authorization records
let mockArticlesCollection = JSON.parse(localStorage.getItem('mock_mongodb_blog_posts')) || [
    {
        _id: "init_1",
        title: "Standard Distributed Storage Clusters Deployments Matrix",
        body: "This deep dive entry details architecture deployment strategies regarding horizontal document clusters parsing loops nodes mapping...",
        author: "system_architect@nexus.io",
        date: "1/15/2026"
    }
];

// Open/Close Operational Actions UI Mapping References
const anonUserActions = document.getElementById('anon-user-actions');
const authUserActions = document.getElementById('auth-user-actions');
const authenticatedUserBadge = document.getElementById('authenticated-user-badge');

const loginModalGate = document.getElementById('login-modal-gate');
const postCompositionModal = document.getElementById('post-composition-modal');

// Mounting Listeners Components Loop Trigger Routing Mappings
document.getElementById('open-login-modal-btn').addEventListener('click', () => loginModalGate.classList.remove('hidden'));
document.querySelector('.close-gate-modal-trigger').addEventListener('click', () => loginModalGate.classList.add('hidden'));

document.getElementById('open-create-post-btn').addEventListener('click', () => {
    resetCompositionForm();
    document.getElementById('composition-modal-title').innerText = "Compile New Log Entry Document";
    postCompositionModal.classList.remove('hidden');
});
document.querySelector('.close-composition-modal-trigger').addEventListener('click', () => postCompositionModal.classList.add('hidden'));

// Identity Verification Engine Route Processing Event Loop Handler
document.getElementById('jwt-identity-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('auth-email-input').value.trim();
    
    // Simulate generation of a secure payload signature base64 encoded token
    const mockJWTHeaderPayload = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
    const mockJWTClaimsPayload = btoa(JSON.stringify({ sub: email, role: "Admin", exp: Date.now() + 3600000 }));
    const simulatedSignedJWTTokenString = `${mockJWTHeaderPayload}.${mockJWTClaimsPayload}.simulatedsignaturebytes`;

    localStorage.setItem('bearer_jwt_token_string', simulatedSignedJWTTokenString);
    localStorage.setItem('bearer_jwt_user_identity', email);

    loginModalGate.classList.add('hidden');
    document.getElementById('jwt-identity-form').reset();
    evaluateAuthenticationStatusState();
});

document.getElementById('logout-gate-btn').addEventListener('click', () => {
    localStorage.removeItem('bearer_jwt_token_string');
    localStorage.removeItem('bearer_jwt_user_identity');
    evaluateAuthenticationStatusState();
});

// Guard Interceptor Hook Logic Verification Processing Engine Check
function evaluateAuthenticationStatusState() {
    const activeToken = localStorage.getItem('bearer_jwt_token_string');
    const activeUser = localStorage.getItem('bearer_jwt_user_identity');

    if (activeToken && activeUser) {
        anonUserActions.classList.add('hidden');
        authUserActions.classList.remove('hidden');
        authenticatedUserBadge.innerText = activeUser;
    } else {
        anonUserActions.classList.remove('hidden');
        authUserActions.classList.add('hidden');
        authenticatedUserBadge.innerText = '';
    }
    renderBlogFeed();
}

// Data Mutation Logic Pipeline CRUD Actions Controller Mapping Loop
const blogCompositionForm = document.getElementById('blog-composition-form');
const compositionTargetId = document.getElementById('composition-target-id');
const postTitleInput = document.getElementById('post-title-input');
const postBodyInput = document.getElementById('post-body-input');

blogCompositionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const activeUser = localStorage.getItem('bearer_jwt_user_identity');
    if(!activeUser) {
        alert("Route Error: Access Denied. Token Signature Not Present.");
        return;
    }

    const id = compositionTargetId.value;
    const title = postTitleInput.value.trim();
    const body = postBodyInput.value.trim();
    const currentTimestamp = new Date().toLocaleDateString();

    if(id) {
        // Document modification execution route
        const index = mockArticlesCollection.findIndex(p => p._id === id);
        if(index !== -1 && (mockArticlesCollection[index].author === activeUser || activeUser === 'system_architect@nexus.io')) {
            mockArticlesCollection[index] = { ...mockArticlesCollection[index], title, body };
        } else {
            alert("Route Error: Access Denied. Identity signature mismatch on targeted update document node.");
        }
    } else {
        // Document creation execution route
        const newArticleDocument = {
            _id: 'art_doc_' + Math.random().toString(36).substr(2, 9),
            title,
            body,
            author: activeUser,
            date: currentTimestamp
        };
        mockArticlesCollection.push(newArticleDocument);
    }

    saveAndRefreshBlogDatabase();
    postCompositionModal.classList.add('hidden');
    resetCompositionForm();
});

function editBlogPostRouteTrigger(id) {
    const targetPost = mockArticlesCollection.find(p => p._id === id);
    if(!targetPost) return;

    compositionTargetId.value = targetPost._id;
    postTitleInput.value = targetPost.title;
    postBodyInput.value = targetPost.body;

    document.getElementById('composition-modal-title').innerText = "Modify Existing Log Entry Document";
    postCompositionModal.classList.remove('hidden');
}

function dropBlogPostRouteTrigger(id) {
    if(confirm("Confirm destructive drop action sequence on target index node document?")) {
        mockArticlesCollection = mockArticlesCollection.filter(p => p._id !== id);
        saveAndRefreshBlogDatabase();
    }
}

function resetCompositionForm() {
    compositionTargetId.value = '';
    blogCompositionForm.reset();
}

function saveAndRefreshBlogDatabase() {
    localStorage.setItem('mock_mongodb_blog_posts', JSON.stringify(mockArticlesCollection));
    renderBlogFeed();
}

// Feed View Stream Parser Engine UI Compilation Method Loop
function renderBlogFeed() {
    const feedTargetContainer = document.getElementById('blog-posts-feed-grid');
    feedTargetContainer.innerHTML = '';

    const activeUserIdentityCache = localStorage.getItem('bearer_jwt_user_identity');

    if(mockArticlesCollection.length === 0) {
        feedTargetContainer.innerHTML = '<p style="color:var(--text-dimmed); text-align:center;">Collection is currently empty.</p>';
        return;
    }

    [...mockArticlesCollection].reverse().forEach(post => {
        const articleCardNode = document.createElement('article');
        articleCardNode.className = 'blog-post-card-node';
        
        // Render secure control buttons if authorization token rules validate successfully
        let administrativeUIPanelBlock = '';
        if(activeUserIdentityCache && (post.author === activeUserIdentityCache || activeUserIdentityCache === 'system_architect@nexus.io')) {
            administrativeUIPanelBlock = `
                <div class="post-admin-actions-row">
                    <button class="btn-edit-action" onclick="editBlogPostRouteTrigger('${post._id}')"><i class="fa-solid fa-code-merge"></i> Edit Document</button>
                    <button class="btn-delete-action" onclick="dropBlogPostRouteTrigger('${post._id}')"><i class="fa-solid fa-dumpster-fire"></i> Drop Document Node</button>
                </div>
            `;
        }

        articleCardNode.innerHTML = `
            <div class="post-card-header">
                <h2>${post.title}</h2>
            </div>
            <div class="post-meta-signature">
                <span>By: ${post.author} • Public Key Index ID: <small>${post._id}</small> • Created: ${post.date}</span>
            </div>
            <p class="post-body-content-string">${post.body}</p>
            ${administrativeUIPanelBlock}
        `;
        feedTargetContainer.appendChild(articleCardNode);
    });
}

// Run Initial Check Logic Chain on Load
window.onload = function() {
    evaluateAuthenticationStatusState();
};