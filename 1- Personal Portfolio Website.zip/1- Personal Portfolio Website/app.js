/**
 * Talha — Personal Portfolio System Engine
 */

// ── Skills Datastore Architecture ───────────────────
const skills = [
    { icon: '⚛️', name: 'React / Next.js', level: 92 },
    { icon: '🎨', name: 'CSS / Tailwind',  level: 88 },
    { icon: '🟨', name: 'JavaScript / TS', level: 90 },
    { icon: '🟢', name: 'Node.js',          level: 80 },
    { icon: '🗄️', name: 'MongoDB / SQL',    level: 75 },
    { icon: '🐙', name: 'Git / GitHub',     level: 85 },
    { icon: '🐳', name: 'Docker / CI/CD',   level: 65 },
    { icon: '🎭', name: 'Figma / Design',   level: 70 },
  ];
  
  // ── Render Skill Cards Iterative Loop ───────────────
  const grid = document.getElementById('skillsGrid');
  skills.forEach(s => {
    grid.insertAdjacentHTML('beforeend', `
      <div class="skill-card">
        <div class="skill-icon">${s.icon}</div>
        <div class="skill-name">${s.name}</div>
        <div class="skill-bar-bg">
          <div class="skill-bar-fill" data-level="${s.level}"></div>
        </div>
      </div>
    `);
  });
  
  // ── Intersection Observer Scroll Progress Driver ─────
  const bars = document.querySelectorAll('.skill-bar-fill');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.width = entry.target.dataset.level + '%';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });
  
  bars.forEach(b => observer.observe(b));
  
  // ── Responsive Navigation Drawer Controller ─────────
  document.getElementById('hamburger').addEventListener('click', () => {
    document.getElementById('navLinks').classList.toggle('open');
  });
  
  // Structural closure event when viewport links are targeted
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.addEventListener('click', () => {
      document.getElementById('navLinks').classList.remove('open');
    });
  });
  
  // ── Contact Form Submission Interceptor ─────────────
  document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    
    btn.textContent = '✓ Message Sent!';
    btn.style.background = '#3dbf6e';
    
    // Clean execution feedback delay reset sequence
    setTimeout(() => {
      e.target.reset();
      btn.textContent = 'Send Message →';
      btn.style.background = '';
    }, 2000);
  });
  
  // ── Sticky Navigation Shadow Pipeline ───────────────
  window.addEventListener('scroll', () => {
    const nav = document.getElementById('navbar');
    if (window.scrollY > 60) {
      nav.style.boxShadow = '0 4px 30px rgba(0,0,0,0.4)';
    } else {
      nav.style.boxShadow = 'none';
    }
  });