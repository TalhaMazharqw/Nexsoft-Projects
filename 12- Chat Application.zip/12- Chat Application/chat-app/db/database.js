// Lightweight JSON file-based database (no native dependencies required)
// Provides persistent storage for users, messages, and rooms

const fs = require('fs');
const path = require('path');

const DB_DIR = path.join(__dirname, '..', 'data');
const FILES = {
  users: path.join(DB_DIR, 'users.json'),
  messages: path.join(DB_DIR, 'messages.json'),
  rooms: path.join(DB_DIR, 'rooms.json'),
};

// Ensure data directory and files exist
function init() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  for (const file of Object.values(FILES)) {
    if (!fs.existsSync(file)) {
      fs.writeFileSync(file, JSON.stringify([]), 'utf-8');
    }
  }
}

function readFile(key) {
  try {
    const raw = fs.readFileSync(FILES[key], 'utf-8');
    return JSON.parse(raw || '[]');
  } catch (err) {
    console.error(`Error reading ${key}:`, err.message);
    return [];
  }
}

function writeFile(key, data) {
  try {
    fs.writeFileSync(FILES[key], JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error(`Error writing ${key}:`, err.message);
    return false;
  }
}

// ---------- USERS ----------
function getUsers() {
  return readFile('users');
}

function getUserById(id) {
  return getUsers().find((u) => u.id === id) || null;
}

function getUserByUsername(username) {
  return getUsers().find(
    (u) => u.username.toLowerCase() === username.toLowerCase()
  ) || null;
}

function createUser(user) {
  const users = getUsers();
  users.push(user);
  writeFile('users', users);
  return user;
}

function updateUser(id, updates) {
  const users = getUsers();
  const idx = users.findIndex((u) => u.id === id);
  if (idx === -1) return null;
  users[idx] = { ...users[idx], ...updates };
  writeFile('users', users);
  return users[idx];
}

function getAllUsersPublic() {
  return getUsers().map((u) => ({
    id: u.id,
    username: u.username,
    avatarColor: u.avatarColor,
    status: u.status,
    lastSeen: u.lastSeen,
  }));
}

// ---------- ROOMS (group chats + private chat pairs) ----------
function getRooms() {
  return readFile('rooms');
}

function getRoomById(id) {
  return getRooms().find((r) => r.id === id) || null;
}

function createRoom(room) {
  const rooms = getRooms();
  rooms.push(room);
  writeFile('rooms', rooms);
  return room;
}

function updateRoom(id, updates) {
  const rooms = getRooms();
  const idx = rooms.findIndex((r) => r.id === id);
  if (idx === -1) return null;
  rooms[idx] = { ...rooms[idx], ...updates };
  writeFile('rooms', rooms);
  return rooms[idx];
}

function getRoomsForUser(userId) {
  return getRooms().filter((r) => r.members.includes(userId));
}

function findPrivateRoom(userIdA, userIdB) {
  return (
    getRooms().find(
      (r) =>
        r.type === 'private' &&
        r.members.length === 2 &&
        r.members.includes(userIdA) &&
        r.members.includes(userIdB)
    ) || null
  );
}

// ---------- MESSAGES ----------
function getMessages() {
  return readFile('messages');
}

function getMessagesForRoom(roomId, limit = 200) {
  const all = getMessages().filter((m) => m.roomId === roomId);
  return all.slice(-limit);
}

function createMessage(message) {
  const messages = getMessages();
  messages.push(message);
  writeFile('messages', messages);
  return message;
}

function updateMessage(id, updates) {
  const messages = getMessages();
  const idx = messages.findIndex((m) => m.id === id);
  if (idx === -1) return null;
  messages[idx] = { ...messages[idx], ...updates };
  writeFile('messages', messages);
  return messages[idx];
}

function deleteMessage(id) {
  const messages = getMessages();
  const filtered = messages.filter((m) => m.id !== id);
  writeFile('messages', filtered);
  return filtered.length !== messages.length;
}

module.exports = {
  init,
  getUsers,
  getUserById,
  getUserByUsername,
  createUser,
  updateUser,
  getAllUsersPublic,
  getRooms,
  getRoomById,
  createRoom,
  updateRoom,
  getRoomsForUser,
  findPrivateRoom,
  getMessages,
  getMessagesForRoom,
  createMessage,
  updateMessage,
  deleteMessage,
};
