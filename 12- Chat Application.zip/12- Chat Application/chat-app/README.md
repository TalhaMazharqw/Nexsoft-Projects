# Wisp — Real-time Chat Application

A full-stack chat application built with **Socket.io**, **Express**, and vanilla **HTML/CSS/JavaScript** (no frontend framework). Includes private messaging, group chats, live presence, persistent history, and a fully animated, responsive UI.

## Features (mapped to requirements)

| Requirement | Implementation |
|---|---|
| Real-time messaging system | Socket.io events (`message:send`, `message:new`) deliver messages instantly to all room members. Optimistic UI shows the message immediately while it confirms with the server. |
| Private and group chat features | REST endpoints create/find private 1-on-1 rooms and multi-member group rooms; Socket.io rooms scope all real-time traffic per conversation. |
| Online/offline user status | Server tracks live socket connections per user; presence broadcasts (`presence:update`) update green status dots and "Last seen" text across the UI in real time, including multi-tab awareness. |
| Store chat history in database | Messages, users, and rooms persist to JSON files on disk (`/data`) via a small custom data layer — survives server restarts. Swappable for a real DB later (see "Notes" below). |
| Build responsive chat interface | Mobile-first layout with a collapsible sidebar, fluid breakpoints, touch-friendly tap targets, and smooth transitions across all screen sizes. |

Bonus features included beyond the brief: JWT authentication (register/login), typing indicators, read receipts (sent/delivered/read ticks), emoji picker, message timestamps with date dividers, toast notifications, animated gradient background blobs, and group member management.

## Tech Stack

- **Backend**: Node.js, Express 5, Socket.io 4
- **Auth**: JWT (jsonwebtoken) + bcryptjs for password hashing
- **Storage**: Custom lightweight JSON file database (no native build dependencies — works anywhere Node runs)
- **Frontend**: Vanilla HTML/CSS/JS, split into modular files (no build step, no framework)

## Project Structure

```
chat-app/
├── server.js                 # Express + Socket.io entry point
├── db/database.js            # JSON file-based persistence layer
├── routes/
│   ├── auth.js                # Register / login / JWT middleware
│   └── chat.js                # Rooms, users, message history REST API
├── sockets/chatSocket.js      # All real-time Socket.io event handling
├── public/
│   ├── index.html
│   ├── css/
│   │   ├── base.css           # Design tokens, resets, shared components
│   │   ├── auth.css           # Login/register screen
│   │   ├── layout.css         # App shell layout
│   │   ├── sidebar.css        # Conversation list
│   │   ├── chat.css           # Messages, bubbles, input bar
│   │   ├── modal.css          # New chat / group / info modals
│   │   └── animations.css     # All keyframes
│   └── js/
│       ├── api.js             # fetch() wrapper for REST calls
│       ├── auth.js            # Login/register form logic
│       ├── state.js           # Central client-side state store
│       ├── ui-sidebar.js       # Renders conversation list
│       ├── ui-chat.js          # Renders messages + input handling
│       ├── ui-modal.js         # New chat/group + room info modals
│       ├── socket-client.js    # Socket.io client + toast helper
│       └── app.js              # Bootstraps the app
└── data/                      # Auto-created JSON "database" files
```

## Setup & Run

```bash
cd chat-app
npm install
npm start
```

Then open **http://localhost:3000** in your browser. The server runs on port 3000 by default (configurable via `.env`).

To try real-time + private/group chat features, open the app in two different browsers (or one normal + one incognito window), register two different accounts, and start chatting — messages, typing indicators, and online status will sync instantly between them.

## How it works

**Auth**: Registering or logging in returns a JWT, stored in `localStorage`. The token authenticates both REST calls (`Authorization: Bearer` header) and the Socket.io handshake (`auth: { token }`).

**Rooms**: A "room" is either `type: "private"` (exactly 2 members) or `type: "group"` (named, many members). Opening a chat joins its Socket.io room server-side, so all members receive new messages, typing events, and read receipts in real time.

**Persistence**: Every message, user, and room is written to a JSON file under `/data` immediately on creation/update. This is intentionally dependency-free (no native compilation needed) so it runs in any standard Node environment; for production scale you'd swap `db/database.js` for a real database (Postgres, MongoDB, etc.) while keeping the same function signatures.

**Presence**: The server keeps an in-memory map of `userId -> active socket ids`. A user is "online" if they have at least one open socket (supports multiple tabs/devices). Disconnects only mark a user offline once their last socket closes.

## Notes / Possible Extensions

- Swap the JSON file store for MongoDB/Postgres for production use (the `db/database.js` interface is already shaped like a typical data-access layer, so the rest of the app wouldn't need to change much).
- Add file/image attachments to messages.
- Add push notifications for offline users.
- Add message editing/deletion and reactions.
