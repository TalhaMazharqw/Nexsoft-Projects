const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/database');
const { JWT_SECRET } = require('../routes/auth');

// Track live socket connections: userId -> Set of socket ids (supports multi-tab)
const userSockets = new Map();

function addUserSocket(userId, socketId) {
  if (!userSockets.has(userId)) {
    userSockets.set(userId, new Set());
  }
  userSockets.get(userId).add(socketId);
}

function removeUserSocket(userId, socketId) {
  if (userSockets.has(userId)) {
    userSockets.get(userId).delete(socketId);
    if (userSockets.get(userId).size === 0) {
      userSockets.delete(userId);
    }
  }
}

function isUserOnline(userId) {
  return userSockets.has(userId) && userSockets.get(userId).size > 0;
}

function initSocket(io) {
  // Authenticate socket connections using the JWT issued at login
  io.use((socket, next) => {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) {
      return next(new Error('Authentication required.'));
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      socket.userId = decoded.id;
      socket.username = decoded.username;
      next();
    } catch (err) {
      next(new Error('Invalid or expired token.'));
    }
  });

  io.on('connection', (socket) => {
    const { userId, username } = socket;
    console.log(`Socket connected: ${username} (${socket.id})`);

    addUserSocket(userId, socket.id);

    // Mark user online and broadcast presence
    db.updateUser(userId, { status: 'online', lastSeen: new Date().toISOString() });

    // Join a room for every chat the user belongs to, so messages reach them
    const rooms = db.getRoomsForUser(userId);
    rooms.forEach((room) => socket.join(room.id));

    // Notify everyone this user is now online
    socket.broadcast.emit('presence:update', {
      userId,
      status: 'online',
      lastSeen: new Date().toISOString(),
    });

    // ---------- JOIN ROOM (used when opening a chat from the UI) ----------
    socket.on('room:join', ({ roomId }) => {
      const room = db.getRoomById(roomId);
      if (room && room.members.includes(userId)) {
        socket.join(roomId);
      }
    });

    // ---------- SEND MESSAGE ----------
    socket.on('message:send', (payload, callback) => {
      try {
        const { roomId, text, tempId } = payload;
        const room = db.getRoomById(roomId);

        if (!room || !room.members.includes(userId)) {
          if (callback) callback({ error: 'You are not a member of this room.' });
          return;
        }
        if (!text || !text.trim()) {
          if (callback) callback({ error: 'Message cannot be empty.' });
          return;
        }

        const message = {
          id: uuidv4(),
          roomId,
          senderId: userId,
          senderUsername: username,
          text: text.trim().slice(0, 4000),
          createdAt: new Date().toISOString(),
          status: 'sent',
          readBy: [userId],
        };

        db.createMessage(message);

        // Broadcast to everyone in the room (including sender, for multi-tab sync)
        io.to(roomId).emit('message:new', message);

        // Push updates to delivered status for online recipients
        const otherMembers = room.members.filter((m) => m !== userId);
        const deliveredTo = otherMembers.filter((m) => isUserOnline(m));
        if (deliveredTo.length > 0) {
          const updated = db.updateMessage(message.id, { status: 'delivered' });
          io.to(roomId).emit('message:status', {
            messageId: message.id,
            status: 'delivered',
          });
        }

        if (callback) callback({ success: true, message, tempId });
      } catch (err) {
        console.error('message:send error', err);
        if (callback) callback({ error: 'Failed to send message.' });
      }
    });

    // ---------- MESSAGE READ RECEIPT ----------
    socket.on('message:read', ({ roomId }) => {
      const room = db.getRoomById(roomId);
      if (!room || !room.members.includes(userId)) return;

      const messages = db.getMessagesForRoom(roomId, 500);
      let changed = false;
      messages.forEach((msg) => {
        if (msg.senderId !== userId && !msg.readBy.includes(userId)) {
          db.updateMessage(msg.id, {
            readBy: [...msg.readBy, userId],
            status: 'read',
          });
          changed = true;
        }
      });

      if (changed) {
        io.to(roomId).emit('message:read:bulk', { roomId, readerId: userId });
      }
    });

    // ---------- TYPING INDICATORS ----------
    socket.on('typing:start', ({ roomId }) => {
      const room = db.getRoomById(roomId);
      if (!room || !room.members.includes(userId)) return;
      socket.to(roomId).emit('typing:update', { roomId, userId, username, isTyping: true });
    });

    socket.on('typing:stop', ({ roomId }) => {
      const room = db.getRoomById(roomId);
      if (!room || !room.members.includes(userId)) return;
      socket.to(roomId).emit('typing:update', { roomId, userId, username, isTyping: false });
    });

    // ---------- NEW GROUP / PRIVATE ROOM CREATED (sync across tabs/members) ----------
    socket.on('room:created', ({ room }) => {
      if (!room) return;
      room.members.forEach((memberId) => {
        const socketIds = userSockets.get(memberId);
        if (socketIds) {
          socketIds.forEach((sid) => {
            const memberSocket = io.sockets.sockets.get(sid);
            if (memberSocket) {
              memberSocket.join(room.id);
              memberSocket.emit('room:new', { room });
            }
          });
        }
      });
    });

    // ---------- DISCONNECT ----------
    socket.on('disconnect', () => {
      console.log(`Socket disconnected: ${username} (${socket.id})`);
      removeUserSocket(userId, socket.id);

      // Only mark fully offline if no other tabs/sessions remain
      if (!isUserOnline(userId)) {
        const lastSeen = new Date().toISOString();
        db.updateUser(userId, { status: 'offline', lastSeen });
        io.emit('presence:update', { userId, status: 'offline', lastSeen });
      }
    });
  });
}

module.exports = { initSocket, isUserOnline };
