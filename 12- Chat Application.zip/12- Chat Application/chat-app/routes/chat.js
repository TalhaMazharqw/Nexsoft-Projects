const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/database');
const { authMiddleware } = require('./auth');

const router = express.Router();

// All routes here require a valid token
router.use(authMiddleware);

// GET /api/chat/users - list all users (for starting private chats)
router.get('/users', (req, res) => {
  const users = db.getAllUsersPublic().filter((u) => u.id !== req.user.id);
  res.json({ users });
});

// GET /api/chat/rooms - list rooms the current user belongs to
router.get('/rooms', (req, res) => {
  const rooms = db.getRoomsForUser(req.user.id);

  const enriched = rooms.map((room) => {
    const messages = db.getMessagesForRoom(room.id, 1);
    const lastMessage = messages[messages.length - 1] || null;

    let displayName = room.name;
    let displayAvatarColor = room.avatarColor || '#999';

    if (room.type === 'private') {
      const otherId = room.members.find((m) => m !== req.user.id);
      const otherUser = db.getUserById(otherId);
      if (otherUser) {
        displayName = otherUser.username;
        displayAvatarColor = otherUser.avatarColor;
      }
    }

    return {
      ...room,
      displayName,
      displayAvatarColor,
      lastMessage,
    };
  });

  // Sort by most recent activity
  enriched.sort((a, b) => {
    const aTime = a.lastMessage ? new Date(a.lastMessage.createdAt).getTime() : new Date(a.createdAt).getTime();
    const bTime = b.lastMessage ? new Date(b.lastMessage.createdAt).getTime() : new Date(b.createdAt).getTime();
    return bTime - aTime;
  });

  res.json({ rooms: enriched });
});

// POST /api/chat/rooms/private - create or fetch a private room with another user
router.post('/rooms/private', (req, res) => {
  const { otherUserId } = req.body;
  if (!otherUserId) {
    return res.status(400).json({ error: 'otherUserId is required.' });
  }
  if (otherUserId === req.user.id) {
    return res.status(400).json({ error: 'Cannot start a chat with yourself.' });
  }

  const otherUser = db.getUserById(otherUserId);
  if (!otherUser) {
    return res.status(404).json({ error: 'User not found.' });
  }

  let room = db.findPrivateRoom(req.user.id, otherUserId);
  if (!room) {
    room = {
      id: uuidv4(),
      type: 'private',
      name: null,
      avatarColor: null,
      members: [req.user.id, otherUserId],
      createdBy: req.user.id,
      createdAt: new Date().toISOString(),
    };
    db.createRoom(room);
  }

  res.json({ room });
});

// POST /api/chat/rooms/group - create a new group room
router.post('/rooms/group', (req, res) => {
  const { name, memberIds } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Group name is required.' });
  }

  const members = Array.from(new Set([req.user.id, ...(memberIds || [])]));
  if (members.length < 2) {
    return res.status(400).json({ error: 'Select at least one other member.' });
  }

  const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#A29BFE', '#00B894', '#E17055'];

  const room = {
    id: uuidv4(),
    type: 'group',
    name: name.trim(),
    avatarColor: colors[Math.floor(Math.random() * colors.length)],
    members,
    createdBy: req.user.id,
    createdAt: new Date().toISOString(),
  };
  db.createRoom(room);

  res.status(201).json({ room });
});

// GET /api/chat/rooms/:roomId/messages - fetch chat history for a room
router.get('/rooms/:roomId/messages', (req, res) => {
  const { roomId } = req.params;
  const room = db.getRoomById(roomId);

  if (!room) {
    return res.status(404).json({ error: 'Room not found.' });
  }
  if (!room.members.includes(req.user.id)) {
    return res.status(403).json({ error: 'You are not a member of this room.' });
  }

  const messages = db.getMessagesForRoom(roomId, 500);
  res.json({ messages, room });
});

// POST /api/chat/rooms/group/:roomId/members - add a member to a group
router.post('/rooms/group/:roomId/members', (req, res) => {
  const { roomId } = req.params;
  const { userId } = req.body;
  const room = db.getRoomById(roomId);

  if (!room || room.type !== 'group') {
    return res.status(404).json({ error: 'Group not found.' });
  }
  if (!room.members.includes(req.user.id)) {
    return res.status(403).json({ error: 'You are not a member of this group.' });
  }
  if (room.members.includes(userId)) {
    return res.status(409).json({ error: 'User is already a member.' });
  }

  const updated = db.updateRoom(roomId, { members: [...room.members, userId] });
  res.json({ room: updated });
});

module.exports = router;
