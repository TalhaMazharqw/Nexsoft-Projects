require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const path = require('path');
const { Server } = require('socket.io');

const db = require('./db/database');
const { router: authRouter } = require('./routes/auth');
const chatRouter = require('./routes/chat');
const { initSocket } = require('./sockets/chatSocket');

// Initialize JSON-file database (creates data/ dir + files if missing)
db.init();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' },
});

const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api/auth', authRouter);
app.use('/api/chat', chatRouter);

// Fallback to index.html for the SPA
app.get('/{*splat}', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Initialize Socket.io event handlers
initSocket(io);

server.listen(PORT, () => {
  console.log(`\n  Chat App running!`);
  console.log(`  Local:  http://localhost:${PORT}\n`);
});
