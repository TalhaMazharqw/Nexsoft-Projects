// auth.js — handles the login/register screen interactions

const Auth = (() => {
  function init() {
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');

    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        tabs.forEach((t) => t.classList.remove('active'));
        forms.forEach((f) => f.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`${tab.dataset.tab}-form`).classList.add('active');
        clearErrors();
      });
    });

    document.getElementById('login-form').addEventListener('submit', handleLogin);
    document.getElementById('register-form').addEventListener('submit', handleRegister);
  }

  function clearErrors() {
    document.querySelectorAll('.auth-error').forEach((el) => {
      el.classList.remove('visible');
      el.textContent = '';
    });
  }

  function showError(formId, message) {
    const errorEl = document.getElementById(formId);
    errorEl.textContent = message;
    errorEl.classList.add('visible');
    errorEl.style.animation = 'none';
    requestAnimationFrame(() => {
      errorEl.style.animation = '';
    });
  }

  function setLoading(button, isLoading) {
    button.classList.toggle('loading', isLoading);
    button.disabled = isLoading;
  }

  async function handleLogin(e) {
    e.preventDefault();
    clearErrors();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    const button = e.target.querySelector('button[type="submit"]');

    setLoading(button, true);
    try {
      const data = await API.login(username, password);
      onAuthSuccess(data);
    } catch (err) {
      showError('login-error', err.message);
    } finally {
      setLoading(button, false);
    }
  }

  async function handleRegister(e) {
    e.preventDefault();
    clearErrors();
    const username = document.getElementById('register-username').value.trim();
    const password = document.getElementById('register-password').value;
    const button = e.target.querySelector('button[type="submit"]');

    setLoading(button, true);
    try {
      const data = await API.register(username, password);
      onAuthSuccess(data);
    } catch (err) {
      showError('register-error', err.message);
    } finally {
      setLoading(button, false);
    }
  }

  function onAuthSuccess(data) {
    localStorage.setItem('wisp_token', data.token);
    localStorage.setItem('wisp_user', JSON.stringify(data.user));
    window.dispatchEvent(new CustomEvent('wisp:authenticated', { detail: data }));
  }

  function logout() {
    localStorage.removeItem('wisp_token');
    localStorage.removeItem('wisp_user');
    window.location.reload();
  }

  function getCurrentUser() {
    const raw = localStorage.getItem('wisp_user');
    return raw ? JSON.parse(raw) : null;
  }

  function isAuthenticated() {
    return !!localStorage.getItem('wisp_token');
  }

  return { init, logout, getCurrentUser, isAuthenticated };
})();
