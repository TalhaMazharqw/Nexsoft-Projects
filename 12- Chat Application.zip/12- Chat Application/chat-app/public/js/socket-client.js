// socket-client.js — manages the Socket.io connection and real-time event flow

const SocketClient = (() => {
  let socket = null;

  function connect() {
    const token = localStorage.getItem('wisp_token');
    socket = io({
      auth: { token },
    });

    socket.on('connect', () => {
      console.log('Connected to server');
    });

    socket.on('connect_error', (err) => {
      console.error('Connection error:', err.message);
      Toast.show('Connection issue — retrying…', 'error');
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from server');
    });

    socket.on('message:new', (message) => {
      const room = State.getRoom(message.roomId);
      if (!room) return;

      ChatUI.appendIncomingMessage(message.roomId, message);

      // Update sidebar preview & ordering
      State.upsertRoom({ ...room, lastMessage: message });
      State.moveRoomToTop(message.roomId);
      SidebarUI.render();

      if (message.senderId !== State.getMe().id && State.getActiveRoom() !== message.roomId) {
        SidebarUI.flashRoom(message.roomId);
        Toast.show(`${message.senderUsername}: ${truncate(message.text, 60)}`, 'info');
      }
    });

    socket.on('message:status', ({ messageId, status }) => {
      const activeRoomId = State.getActiveRoom();
      if (activeRoomId) {
        State.updateMessageStatus(activeRoomId, messageId, status);
        ChatUI.renderMessages(activeRoomId);
      }
    });

    socket.on('message:read:bulk', ({ roomId, readerId }) => {
      const msgs = State.getMessages(roomId);
      msgs.forEach((m) => {
        if (m.senderId !== readerId) {
          m.status = 'read';
          if (!m.readBy.includes(readerId)) m.readBy.push(readerId);
        }
      });
      ChatUI.refreshIfActive(roomId);
    });

    socket.on('presence:update', ({ userId, status, lastSeen }) => {
      State.updateUserPresence(userId, status, lastSeen);
      SidebarUI.render();
      const activeRoom = State.getRoom(State.getActiveRoom());
      if (activeRoom && activeRoom.type === 'private' && activeRoom.members.includes(userId)) {
        ChatUI.updateHeaderStatus(activeRoom);
      }
    });

    socket.on('typing:update', ({ roomId, userId, isTyping }) => {
      State.setTyping(roomId, userId, isTyping);
      const room = State.getRoom(roomId);
      if (room) {
        if (State.getActiveRoom() === roomId) {
          ChatUI.updateTypingIndicator(room);
        }
        SidebarUI.render();
      }
    });

    socket.on('room:new', ({ room }) => {
      const enriched = enrichIncomingRoom(room);
      State.upsertRoom(enriched);
      SidebarUI.render();
      Toast.show(
        room.type === 'group' ? `You were added to "${room.name}"` : 'New conversation started',
        'success'
      );
    });
  }

  function enrichIncomingRoom(room) {
    if (room.type === 'private') {
      const otherId = room.members.find((m) => m !== State.getMe().id);
      const otherUser = State.getUser(otherId);
      return {
        ...room,
        displayName: otherUser ? otherUser.username : 'Unknown',
        displayAvatarColor: otherUser ? otherUser.avatarColor : '#999',
        lastMessage: null,
      };
    }
    return { ...room, displayName: room.name, displayAvatarColor: room.avatarColor, lastMessage: null };
  }

  function truncate(str, len) {
    return str.length > len ? str.slice(0, len) + '…' : str;
  }

  function joinRoom(roomId) {
    socket.emit('room:join', { roomId });
  }

  function sendMessage(roomId, text, tempId, callback) {
    socket.emit('message:send', { roomId, text, tempId }, callback);
  }

  function markRead(roomId) {
    socket.emit('message:read', { roomId });
  }

  function emitTypingStart(roomId) {
    socket.emit('typing:start', { roomId });
  }

  function emitTypingStop(roomId) {
    socket.emit('typing:stop', { roomId });
  }

  function notifyRoomCreated(room) {
    socket.emit('room:created', { room });
  }

  return {
    connect,
    joinRoom,
    sendMessage,
    markRead,
    emitTypingStart,
    emitTypingStop,
    notifyRoomCreated,
  };
})();

// Tiny toast helper used across modules
const Toast = (() => {
  function show(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('exiting');
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }
  return { show };
})();
