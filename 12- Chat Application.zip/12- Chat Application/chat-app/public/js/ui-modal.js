// ui-modal.js — handles the "new chat / group" modal and room info modal

const ModalUI = (() => {
  let allUsers = [];
  let selectedGroupMembers = new Set();

  function init() {
    document.getElementById('new-chat-btn').addEventListener('click', openNewChatModal);
    document.getElementById('close-modal-btn').addEventListener('click', closeNewChatModal);
    document.getElementById('new-chat-modal').addEventListener('click', (e) => {
      if (e.target.id === 'new-chat-modal') closeNewChatModal();
    });

    document.querySelectorAll('.modal-tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.modal-tab').forEach((t) => t.classList.remove('active'));
        document.querySelectorAll('.modal-pane').forEach((p) => p.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`pane-${tab.dataset.modalTab}`).classList.add('active');
      });
    });

    document.getElementById('user-search-private').addEventListener('input', (e) => {
      renderUserList('private', e.target.value.trim().toLowerCase());
    });
    document.getElementById('user-search-group').addEventListener('input', (e) => {
      renderUserList('group', e.target.value.trim().toLowerCase());
    });

    document.getElementById('group-name-input').addEventListener('input', updateCreateGroupButton);
    document.getElementById('create-group-btn').addEventListener('click', handleCreateGroup);

    document.getElementById('close-room-info-btn').addEventListener('click', closeRoomInfo);
    document.getElementById('room-info-modal').addEventListener('click', (e) => {
      if (e.target.id === 'room-info-modal') closeRoomInfo();
    });
  }

  async function openNewChatModal() {
    document.getElementById('new-chat-modal').classList.remove('hidden');
    try {
      const data = await API.getUsers();
      allUsers = data.users;
      State.setUsers(allUsers);
      renderUserList('private', '');
      renderUserList('group', '');
    } catch (err) {
      Toast.show('Could not load users.', 'error');
    }
  }

  function closeNewChatModal() {
    document.getElementById('new-chat-modal').classList.add('hidden');
    selectedGroupMembers.clear();
    document.getElementById('group-name-input').value = '';
    updateCreateGroupButton();
  }

  function renderUserList(mode, search) {
    const containerId = mode === 'private' ? 'user-list-private' : 'user-list-group';
    const container = document.getElementById(containerId);

    const filtered = allUsers.filter((u) => u.username.toLowerCase().includes(search));

    if (filtered.length === 0) {
      container.innerHTML = `<div class="empty-state"><p>No users found.</p></div>`;
      return;
    }

    container.innerHTML = filtered
      .map((u) => {
        const isSelected = mode === 'group' && selectedGroupMembers.has(u.id);
        return `
          <div class="user-pick-item ${isSelected ? 'selected' : ''}" data-user-id="${u.id}" data-mode="${mode}">
            <div class="avatar avatar-sm" style="background:${u.avatarColor}">${SidebarUI.initials(u.username)}</div>
            <div class="user-pick-name">
              ${SidebarUI.escapeHtml(u.username)}
              <span class="upn-status">${u.status === 'online' ? 'Online' : 'Offline'}</span>
            </div>
            ${mode === 'group' ? `<div class="checkbox"><svg viewBox="0 0 24 24" fill="none"><path d="M5 12l5 5L20 7" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg></div>` : ''}
          </div>
        `;
      })
      .join('');

    container.querySelectorAll('.user-pick-item').forEach((item) => {
      item.addEventListener('click', () => handleUserPick(item));
    });
  }

  async function handleUserPick(item) {
    const userId = item.dataset.userId;
    const mode = item.dataset.mode;

    if (mode === 'private') {
      try {
        const data = await API.createPrivateRoom(userId);
        const enrichedRoom = enrichPrivateRoom(data.room);
        State.upsertRoom(enrichedRoom);
        SidebarUI.render();
        closeNewChatModal();
        ChatUI.openRoom(enrichedRoom.id);
        SocketClient.notifyRoomCreated(enrichedRoom);
      } catch (err) {
        Toast.show(err.message, 'error');
      }
    } else {
      if (selectedGroupMembers.has(userId)) {
        selectedGroupMembers.delete(userId);
      } else {
        selectedGroupMembers.add(userId);
      }
      item.classList.toggle('selected');
      updateCreateGroupButton();
    }
  }

  function enrichPrivateRoom(room) {
    const otherId = room.members.find((m) => m !== State.getMe().id);
    const otherUser = State.getUser(otherId) || allUsers.find((u) => u.id === otherId);
    return {
      ...room,
      displayName: otherUser ? otherUser.username : 'Unknown',
      displayAvatarColor: otherUser ? otherUser.avatarColor : '#999',
      lastMessage: room.lastMessage || null,
    };
  }

  function updateCreateGroupButton() {
    const name = document.getElementById('group-name-input').value.trim();
    document.getElementById('create-group-btn').disabled = !(name && selectedGroupMembers.size > 0);
  }

  async function handleCreateGroup() {
    const name = document.getElementById('group-name-input').value.trim();
    const memberIds = Array.from(selectedGroupMembers);

    try {
      const data = await API.createGroupRoom(name, memberIds);
      const enrichedRoom = { ...data.room, displayName: data.room.name, displayAvatarColor: data.room.avatarColor, lastMessage: null };
      State.upsertRoom(enrichedRoom);
      SidebarUI.render();
      closeNewChatModal();
      ChatUI.openRoom(enrichedRoom.id);
      SocketClient.notifyRoomCreated(enrichedRoom);
      Toast.show(`Group "${name}" created!`, 'success');
    } catch (err) {
      Toast.show(err.message, 'error');
    }
  }

  function openRoomInfo(roomId) {
    const room = State.getRoom(roomId);
    if (!room) return;

    const body = document.getElementById('room-info-body');
    const memberList = room.members
      .map((id) => {
        const isMe = id === State.getMe().id;
        const user = isMe ? State.getMe() : State.getUser(id);
        if (!user) return '';
        return `
          <div class="room-info-member">
            <div class="avatar avatar-sm" style="background:${user.avatarColor}">${SidebarUI.initials(user.username)}</div>
            <div class="room-info-member-name">
              ${SidebarUI.escapeHtml(user.username)}${isMe ? ' (You)' : ''}
              <span>${user.status === 'online' ? 'Online' : 'Offline'}</span>
            </div>
          </div>
        `;
      })
      .join('');

    body.innerHTML = `
      <div class="room-info-avatar-block">
        <div class="avatar" style="background:${room.displayAvatarColor}">
          ${room.type === 'group' ? `<svg viewBox="0 0 24 24" fill="none" style="width:28px;height:28px"><path d="M17 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M16 3.13a4 4 0 0 1 0 7.75M21 20v-2a4 4 0 0 0-3-3.85" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke="white" stroke-width="2"/></svg>` : SidebarUI.initials(room.displayName)}
        </div>
        <h4>${SidebarUI.escapeHtml(room.displayName)}</h4>
        <span>${room.type === 'group' ? `${room.members.length} members` : 'Direct message'}</span>
      </div>
      <div class="room-info-section-title">Members</div>
      ${memberList}
    `;

    document.getElementById('room-info-modal').classList.remove('hidden');
  }

  function closeRoomInfo() {
    document.getElementById('room-info-modal').classList.add('hidden');
  }

  return { init, openRoomInfo };
})();
