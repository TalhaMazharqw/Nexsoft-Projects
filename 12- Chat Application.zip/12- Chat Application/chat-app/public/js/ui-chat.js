// ui-chat.js — renders the active chat panel: messages, header, input bar

const ChatUI = (() => {
  let typingTimeout = null;
  let isCurrentlyTyping = false;

  const EMOJI_LIST = [
    '😀', '😂', '🥰', '😎', '🤔', '😴', '😢', '😡', '🥳', '😱',
    '👍', '👎', '👏', '🙏', '💪', '🤝', '✌️', '🤞', '👀', '🔥',
    '❤️', '💙', '💚', '💛', '🧡', '💜', '🖤', '💯', '✨', '🎉',
    '🚀', '⭐', '☕', '🍕', '🎮', '📚', '🎵', '⚽', '🐶', '🐱',
  ];

  function init() {
    document.getElementById('message-form').addEventListener('submit', handleSend);

    const textarea = document.getElementById('message-input');
    textarea.addEventListener('input', handleInputChange);
    textarea.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend(e);
      }
    });

    document.getElementById('mobile-back-btn').addEventListener('click', () => {
      document.getElementById('sidebar').classList.remove('slide-out');
    });

    document.getElementById('room-info-btn').addEventListener('click', () => {
      ModalUI.openRoomInfo(State.getActiveRoom());
    });

    initEmojiPicker();

    document.getElementById('messages-container').addEventListener('scroll', () => {
      // Reserved for future "scroll to load more history" feature
    });
  }

  function initEmojiPicker() {
    const picker = document.getElementById('emoji-picker');
    const toggle = document.getElementById('emoji-toggle');

    picker.innerHTML = EMOJI_LIST.map((e) => `<button type="button">${e}</button>`).join('');

    picker.addEventListener('click', (e) => {
      if (e.target.tagName === 'BUTTON') {
        const textarea = document.getElementById('message-input');
        textarea.value += e.target.textContent;
        textarea.dispatchEvent(new Event('input'));
        textarea.focus();
      }
    });

    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      picker.classList.toggle('hidden');
    });

    document.addEventListener('click', (e) => {
      if (!picker.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
        picker.classList.add('hidden');
      }
    });
  }

  function handleInputChange(e) {
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';

    const sendBtn = document.getElementById('send-btn');
    sendBtn.disabled = textarea.value.trim().length === 0;

    const roomId = State.getActiveRoom();
    if (!roomId) return;

    if (textarea.value.trim().length > 0) {
      if (!isCurrentlyTyping) {
        isCurrentlyTyping = true;
        SocketClient.emitTypingStart(roomId);
      }
      clearTimeout(typingTimeout);
      typingTimeout = setTimeout(() => {
        isCurrentlyTyping = false;
        SocketClient.emitTypingStop(roomId);
      }, 1800);
    } else {
      isCurrentlyTyping = false;
      SocketClient.emitTypingStop(roomId);
      clearTimeout(typingTimeout);
    }
  }

  function handleSend(e) {
    e.preventDefault();
    const textarea = document.getElementById('message-input');
    const text = textarea.value.trim();
    const roomId = State.getActiveRoom();
    if (!text || !roomId) return;

    const tempId = 'temp-' + Date.now();
    const me = State.getMe();

    const optimisticMessage = {
      id: tempId,
      roomId,
      senderId: me.id,
      senderUsername: me.username,
      text,
      createdAt: new Date().toISOString(),
      status: 'sending',
      readBy: [me.id],
      _optimistic: true,
    };

    State.addMessage(roomId, optimisticMessage);
    renderMessages(roomId);
    scrollToBottom();

    textarea.value = '';
    textarea.style.height = 'auto';
    document.getElementById('send-btn').disabled = true;
    document.getElementById('send-btn').classList.add('bump');
    setTimeout(() => document.getElementById('send-btn').classList.remove('bump'), 300);

    isCurrentlyTyping = false;
    SocketClient.emitTypingStop(roomId);

    SocketClient.sendMessage(roomId, text, tempId, (response) => {
      if (response && response.error) {
        Toast.show(response.error, 'error');
        return;
      }
      if (response && response.success) {
        // Replace optimistic message with the confirmed one
        const msgs = State.getMessages(roomId);
        const idx = msgs.findIndex((m) => m.id === tempId);
        if (idx !== -1) {
          msgs[idx] = response.message;
          renderMessages(roomId);
        }
      }
    });
  }

  function openRoom(roomId) {
    State.setActiveRoom(roomId);
    SidebarUI.setActive(roomId);

    const room = State.getRoom(roomId);
    if (!room) return;

    document.getElementById('chat-empty-state').classList.add('hidden');
    const activeEl = document.getElementById('chat-active');
    activeEl.classList.remove('hidden');
    activeEl.classList.add('activating');

    // Mobile: slide sidebar away
    if (window.innerWidth <= 768) {
      document.getElementById('sidebar').classList.add('slide-out');
    }

    renderHeader(room);
    renderMessages(roomId);
    scrollToBottom(false);

    SocketClient.joinRoom(roomId);
    SocketClient.markRead(roomId);

    document.getElementById('message-input').focus();
  }

  function renderHeader(room) {
    const avatarEl = document.getElementById('chat-header-avatar');
    avatarEl.style.background = room.displayAvatarColor || '#999';
    avatarEl.innerHTML =
      room.type === 'group'
        ? `<svg viewBox="0 0 24 24" fill="none" style="width:20px;height:20px"><path d="M17 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M16 3.13a4 4 0 0 1 0 7.75M21 20v-2a4 4 0 0 0-3-3.85" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke="white" stroke-width="2"/></svg>`
        : SidebarUI.initials(room.displayName || '?');

    document.getElementById('chat-header-name').textContent = room.displayName || 'Unknown';
    updateHeaderStatus(room);
  }

  function updateHeaderStatus(room) {
    const statusEl = document.getElementById('chat-header-status');
    const typingUsers = State.getTypingUsers(room.id);

    if (typingUsers.length > 0) {
      statusEl.textContent = room.type === 'group'
        ? `${typingUsers.map((id) => (State.getUser(id) || {}).username || 'Someone').join(', ')} typing…`
        : 'typing…';
      statusEl.className = 'chat-header-status is-typing';
      return;
    }

    if (room.type === 'group') {
      statusEl.textContent = `${room.members.length} members`;
      statusEl.className = 'chat-header-status';
    } else {
      const otherId = room.members.find((m) => m !== State.getMe().id);
      const user = State.getUser(otherId);
      if (user && user.status === 'online') {
        statusEl.textContent = 'Online';
        statusEl.className = 'chat-header-status is-online';
      } else {
        const lastSeen = user && user.lastSeen ? SidebarUI.timeAgo(user.lastSeen) + ' ago' : '';
        statusEl.textContent = lastSeen ? `Last seen ${lastSeen}` : 'Offline';
        statusEl.className = 'chat-header-status';
      }
    }
  }

  function renderMessages(roomId) {
    const listEl = document.getElementById('messages-list');
    const messages = State.getMessages(roomId);
    const me = State.getMe();
    const room = State.getRoom(roomId);

    listEl.innerHTML = '';

    let lastDate = null;
    let lastSenderId = null;

    messages.forEach((msg, i) => {
      const msgDate = new Date(msg.createdAt).toDateString();
      if (msgDate !== lastDate) {
        listEl.appendChild(buildDateDivider(msg.createdAt));
        lastDate = msgDate;
        lastSenderId = null;
      }

      const isMine = msg.senderId === me.id;
      const showAvatar = !isMine && lastSenderId !== msg.senderId;
      const showSenderLabel = room.type === 'group' && !isMine && lastSenderId !== msg.senderId;

      listEl.appendChild(buildMessageRow(msg, isMine, showAvatar, showSenderLabel, i));
      lastSenderId = msg.senderId;
    });

    updateTypingIndicator(room);
  }

  function buildDateDivider(isoString) {
    const div = document.createElement('div');
    div.className = 'date-divider';
    const date = new Date(isoString);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    let label;
    if (date.toDateString() === today.toDateString()) {
      label = 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      label = 'Yesterday';
    } else {
      label = date.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' });
    }
    div.innerHTML = `<span>${label}</span>`;
    return div;
  }

  function buildMessageRow(msg, isMine, showAvatar, showSenderLabel, idx) {
    const row = document.createElement('div');
    row.className = `message-row ${isMine ? 'mine' : ''}`;
    row.dataset.messageId = msg.id;
    row.style.animationDelay = `${Math.min(idx * 0.01, 0.15)}s`;

    const sender = State.getUser(msg.senderId);
    const senderColor = isMine ? State.getMe().avatarColor : (sender ? sender.avatarColor : '#999');
    const senderName = isMine ? State.getMe().username : msg.senderUsername;

    const avatarHtml = !isMine
      ? showAvatar
        ? `<div class="avatar avatar-sm" style="background:${senderColor}">${SidebarUI.initials(senderName)}</div>`
        : `<div class="spacer-avatar"></div>`
      : '';

    const time = new Date(msg.createdAt).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

    let metaHtml = `<span>${time}</span>`;
    if (isMine) {
      metaHtml += `<span class="ticks ${msg.status}">${ticksSvg(msg.status)}</span>`;
    }

    row.innerHTML = `
      ${avatarHtml}
      <div class="message-group">
        ${showSenderLabel ? `<span class="sender-label">${SidebarUI.escapeHtml(senderName)}</span>` : ''}
        <div class="bubble">${linkify(SidebarUI.escapeHtml(msg.text))}</div>
        <div class="bubble-meta">${metaHtml}</div>
      </div>
    `;
    return row;
  }

  function linkify(text) {
    return text.replace(/\n/g, '<br>');
  }

  function ticksSvg(status) {
    if (status === 'sending') {
      return `<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2" stroke-dasharray="40" stroke-dashoffset="10"/></svg>`;
    }
    if (status === 'read') {
      return `<svg viewBox="0 0 24 24" fill="none"><path d="M2 12l5 5L17 7M9 12l5 5L24 7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    }
    if (status === 'delivered') {
      return `<svg viewBox="0 0 24 24" fill="none"><path d="M2 12l5 5L17 7M9 12l5 5L24 7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    }
    // sent (single tick)
    return `<svg viewBox="0 0 24 24" fill="none"><path d="M5 12l5 5L20 7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }

  function updateTypingIndicator(room) {
    const typingUsers = State.getTypingUsers(room.id).filter((id) => id !== State.getMe().id);
    const indicator = document.getElementById('typing-indicator');
    const avatarEl = document.getElementById('typing-avatar');

    if (typingUsers.length > 0) {
      const user = State.getUser(typingUsers[0]);
      avatarEl.style.background = user ? user.avatarColor : '#999';
      avatarEl.textContent = user ? SidebarUI.initials(user.username) : '?';
      indicator.classList.remove('hidden');
    } else {
      indicator.classList.add('hidden');
    }

    updateHeaderStatus(room);
  }

  function scrollToBottom(smooth = true) {
    const container = document.getElementById('messages-container');
    requestAnimationFrame(() => {
      container.scrollTo({
        top: container.scrollHeight,
        behavior: smooth ? 'smooth' : 'auto',
      });
    });
  }

  function appendIncomingMessage(roomId, message) {
    State.addMessage(roomId, message);
    if (State.getActiveRoom() === roomId) {
      renderMessages(roomId);
      scrollToBottom();
      SocketClient.markRead(roomId);
    }
  }

  function refreshIfActive(roomId) {
    if (State.getActiveRoom() === roomId) {
      const room = State.getRoom(roomId);
      renderMessages(roomId);
      renderHeader(room);
    }
  }

  return {
    init,
    openRoom,
    renderMessages,
    appendIncomingMessage,
    refreshIfActive,
    updateTypingIndicator,
    updateHeaderStatus,
    scrollToBottom,
  };
})();
