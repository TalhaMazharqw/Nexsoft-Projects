// api.js — lightweight wrapper around fetch() for talking to our REST endpoints

const API = (() => {
  function getToken() {
    return localStorage.getItem('wisp_token');
  }

  async function request(path, options = {}) {
    const token = getToken();
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(path, { ...options, headers });
    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const error = new Error(data.error || 'Request failed');
      error.status = res.status;
      throw error;
    }
    return data;
  }

  return {
    register: (username, password) =>
      request('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      }),

    login: (username, password) =>
      request('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      }),

    getUsers: () => request('/api/chat/users'),

    getRooms: () => request('/api/chat/rooms'),

    createPrivateRoom: (otherUserId) =>
      request('/api/chat/rooms/private', {
        method: 'POST',
        body: JSON.stringify({ otherUserId }),
      }),

    createGroupRoom: (name, memberIds) =>
      request('/api/chat/rooms/group', {
        method: 'POST',
        body: JSON.stringify({ name, memberIds }),
      }),

    getMessages: (roomId) => request(`/api/chat/rooms/${roomId}/messages`),
  };
})();
