// ui-sidebar.js — renders the room list and handles sidebar interactions

const SidebarUI = (() => {
  let searchTerm = '';

  function init() {
    const me = State.getMe();
    document.getElementById('me-username').textContent = me.username;
    const avatarEl = document.getElementById('me-avatar');
    avatarEl.textContent = initials(me.username);
    avatarEl.style.background = me.avatarColor;

    document.getElementById('search-rooms').addEventListener('input', (e) => {
      searchTerm = e.target.value.trim().toLowerCase();
      render();
    });

    document.getElementById('logout-btn').addEventListener('click', () => {
      Auth.logout();
    });
  }

  function initials(name) {
    return name.trim().slice(0, 2).toUpperCase();
  }

  function timeAgo(isoString) {
    if (!isoString) return '';
    const date = new Date(isoString);
    const diffMs = Date.now() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return 'now';
    if (diffMin < 60) return `${diffMin}m`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `${diffHr}h`;
    const diffDay = Math.floor(diffHr / 24);
    if (diffDay < 7) return `${diffDay}d`;
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }

  function render() {
    const listEl = document.getElementById('room-list');
    const emptyEl = document.getElementById('room-list-empty');
    const rooms = State.getRooms();

    const filtered = rooms.filter((r) => {
      if (!searchTerm) return true;
      return (r.displayName || '').toLowerCase().includes(searchTerm);
    });

    listEl.querySelectorAll('.room-item').forEach((el) => el.remove());

    if (filtered.length === 0) {
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    filtered.forEach((room, i) => {
      const el = buildRoomItem(room);
      el.style.animationDelay = `${i * 0.04}s`;
      listEl.appendChild(el);
    });
  }

  function buildRoomItem(room) {
    const div = document.createElement('div');
    div.className = 'room-item';
    div.dataset.roomId = room.id;
    if (room.id === State.getActiveRoom()) {
      div.classList.add('active');
    }

    const isOnline = room.type === 'private' && isOtherUserOnline(room);
    const typingUsers = State.getTypingUsers(room.id);
    const isTyping = typingUsers.length > 0;

    let previewText = 'Say hello \u{1F44B}';
    if (isTyping) {
      previewText = 'typing…';
    } else if (room.lastMessage) {
      const prefix =
        room.type === 'group' && room.lastMessage.senderId !== State.getMe().id
          ? `${room.lastMessage.senderUsername}: `
          : '';
      previewText = prefix + room.lastMessage.text;
    }

    div.innerHTML = `
      <div class="room-avatar-wrap">
        <div class="avatar" style="background:${room.displayAvatarColor || '#999'}">
          ${room.type === 'group' ? groupIconSvg() : initials(room.displayName || '?')}
        </div>
        ${room.type === 'private' ? `<span class="status-dot ${isOnline ? 'online' : ''}"></span>` : ''}
      </div>
      <div class="room-item-content">
        <div class="room-item-top">
          <span class="room-item-name">${escapeHtml(room.displayName || 'Unknown')}${room.type === 'group' ? '<span class="group-badge">Group</span>' : ''}</span>
          <span class="room-item-time">${room.lastMessage ? timeAgo(room.lastMessage.createdAt) : ''}</span>
        </div>
        <span class="room-item-preview ${isTyping ? 'typing-now' : ''}">${escapeHtml(previewText)}</span>
      </div>
    `;

    div.addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('wisp:room-selected', { detail: { roomId: room.id } }));
    });

    return div;
  }

  function isOtherUserOnline(room) {
    const otherId = room.members.find((m) => m !== State.getMe().id);
    const user = State.getUser(otherId);
    return user && user.status === 'online';
  }

  function groupIconSvg() {
    return `<svg viewBox="0 0 24 24" fill="none" style="width:20px;height:20px"><path d="M17 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M16 3.13a4 4 0 0 1 0 7.75M21 20v-2a4 4 0 0 0-3-3.85" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke="white" stroke-width="2"/></svg>`;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function setActive(roomId) {
    document.querySelectorAll('.room-item').forEach((el) => {
      el.classList.toggle('active', el.dataset.roomId === roomId);
    });
  }

  function flashRoom(roomId) {
    const el = document.querySelector(`.room-item[data-room-id="${roomId}"]`);
    if (el) {
      el.classList.remove('flash');
      requestAnimationFrame(() => el.classList.add('flash'));
    }
  }

  return { init, render, setActive, flashRoom, timeAgo, initials, escapeHtml };
})();
