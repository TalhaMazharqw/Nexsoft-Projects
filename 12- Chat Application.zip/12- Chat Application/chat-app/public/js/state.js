// state.js — single source of truth for client-side app state

const State = (() => {
  const state = {
    me: null,             // current user { id, username, avatarColor }
    rooms: [],             // array of room objects (enriched with displayName etc.)
    activeRoomId: null,
    messagesByRoom: {},    // roomId -> array of message objects
    usersById: {},         // userId -> { id, username, avatarColor, status, lastSeen }
    typingByRoom: {},      // roomId -> Set of userIds currently typing
  };

  function setMe(user) {
    state.me = user;
  }

  function getMe() {
    return state.me;
  }

  function setRooms(rooms) {
    state.rooms = rooms;
    rooms.forEach((r) => {
      if (!state.messagesByRoom[r.id]) {
        state.messagesByRoom[r.id] = [];
      }
    });
  }

  function getRooms() {
    return state.rooms;
  }

  function getRoom(roomId) {
    return state.rooms.find((r) => r.id === roomId) || null;
  }

  function upsertRoom(room) {
    const idx = state.rooms.findIndex((r) => r.id === room.id);
    if (idx === -1) {
      state.rooms.unshift(room);
    } else {
      state.rooms[idx] = { ...state.rooms[idx], ...room };
    }
    if (!state.messagesByRoom[room.id]) {
      state.messagesByRoom[room.id] = [];
    }
  }

  function setActiveRoom(roomId) {
    state.activeRoomId = roomId;
  }

  function getActiveRoom() {
    return state.activeRoomId;
  }

  function setMessages(roomId, messages) {
    state.messagesByRoom[roomId] = messages;
  }

  function getMessages(roomId) {
    return state.messagesByRoom[roomId] || [];
  }

  function addMessage(roomId, message) {
    if (!state.messagesByRoom[roomId]) {
      state.messagesByRoom[roomId] = [];
    }
    // Avoid duplicate insertion (can happen with optimistic UI + socket echo)
    const exists = state.messagesByRoom[roomId].some((m) => m.id === message.id);
    if (!exists) {
      state.messagesByRoom[roomId].push(message);
    }
  }

  function updateMessageStatus(roomId, messageId, status) {
    const msgs = state.messagesByRoom[roomId];
    if (!msgs) return;
    const msg = msgs.find((m) => m.id === messageId);
    if (msg) msg.status = status;
  }

  function setUsers(users) {
    users.forEach((u) => {
      state.usersById[u.id] = u;
    });
  }

  function getUser(userId) {
    return state.usersById[userId] || null;
  }

  function updateUserPresence(userId, status, lastSeen) {
    if (state.usersById[userId]) {
      state.usersById[userId].status = status;
      state.usersById[userId].lastSeen = lastSeen;
    } else {
      state.usersById[userId] = { id: userId, status, lastSeen };
    }
  }

  function setTyping(roomId, userId, isTyping) {
    if (!state.typingByRoom[roomId]) {
      state.typingByRoom[roomId] = new Set();
    }
    if (isTyping) {
      state.typingByRoom[roomId].add(userId);
    } else {
      state.typingByRoom[roomId].delete(userId);
    }
  }

  function getTypingUsers(roomId) {
    return Array.from(state.typingByRoom[roomId] || []);
  }

  function moveRoomToTop(roomId) {
    const idx = state.rooms.findIndex((r) => r.id === roomId);
    if (idx > 0) {
      const [room] = state.rooms.splice(idx, 1);
      state.rooms.unshift(room);
    }
  }

  return {
    setMe,
    getMe,
    setRooms,
    getRooms,
    getRoom,
    upsertRoom,
    setActiveRoom,
    getActiveRoom,
    setMessages,
    getMessages,
    addMessage,
    updateMessageStatus,
    setUsers,
    getUser,
    updateUserPresence,
    setTyping,
    getTypingUsers,
    moveRoomToTop,
  };
})();
