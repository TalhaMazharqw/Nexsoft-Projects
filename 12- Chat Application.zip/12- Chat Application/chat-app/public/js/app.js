// app.js — application bootstrap: decides between auth screen and main app,
// wires up initial data loading

(function bootstrap() {
  Auth.init();

  if (Auth.isAuthenticated()) {
    startApp();
  }

  window.addEventListener('wisp:authenticated', () => {
    document.getElementById('auth-screen').classList.add('hidden');
    startApp();
  });

  window.addEventListener('wisp:room-selected', (e) => {
    ChatUI.openRoom(e.detail.roomId);
  });
})();

async function startApp() {
  const me = Auth.getCurrentUser();
  if (!me) {
    Auth.logout();
    return;
  }
  State.setMe(me);

  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('app-screen').classList.remove('hidden');

  SidebarUI.init();
  ChatUI.init();
  ModalUI.init();
  SocketClient.connect();

  await loadInitialData();
}

async function loadInitialData() {
  try {
    const [usersData, roomsData] = await Promise.all([API.getUsers(), API.getRooms()]);
    State.setUsers(usersData.users);
    State.setRooms(roomsData.rooms);
    SidebarUI.render();

    // Pre-fetch message history for each room so switching feels instant
    await Promise.all(
      roomsData.rooms.map(async (room) => {
        try {
          const msgData = await API.getMessages(room.id);
          State.setMessages(room.id, msgData.messages);
        } catch (err) {
          console.error(`Failed to load messages for room ${room.id}`, err);
        }
      })
    );
  } catch (err) {
    console.error('Failed to load initial data', err);
    Toast.show('Could not load your conversations.', 'error');
  }
}
