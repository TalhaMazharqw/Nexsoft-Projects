// ===== Tiny auth layer backed by localStorage =====
const STORE = {
  users: 'tf_users',
  session: 'tf_session',
  tasks: 'tf_tasks',
  activity: 'tf_activity',
};

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
}
function save(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

function seed() {
  if (!load(STORE.users, null)) {
    save(STORE.users, [
      { id: 'u1', name: 'Admin User',   email: 'admin@taskflow.io',   password: 'admin123',   role: 'admin'   },
      { id: 'u2', name: 'Maya Manager', email: 'maya@taskflow.io',    password: 'maya1234',   role: 'manager' },
      { id: 'u3', name: 'Marco Member', email: 'marco@taskflow.io',   password: 'marco1234',  role: 'member'  },
    ]);
  }
  if (!load(STORE.tasks, null)) {
    const now = Date.now();
    save(STORE.tasks, [
      { id: 't1', title: 'Design landing page', desc: 'Hero, features, pricing.', status: 'in_progress', priority: 'High',   assignee: 'u2', due: new Date(now+86400000*3).toISOString().slice(0,10), createdBy:'u1', createdAt: now, comments: [] },
      { id: 't2', title: 'Set up CI/CD',         desc: 'GitHub Actions deploy.',    status: 'todo',         priority: 'Urgent', assignee: 'u1', due: new Date(now+86400000).toISOString().slice(0,10),   createdBy:'u1', createdAt: now, comments: [] },
      { id: 't3', title: 'Write API docs',       desc: 'OpenAPI 3.0 spec.',         status: 'done',         priority: 'Medium', assignee: 'u3', due: new Date(now-86400000).toISOString().slice(0,10),   createdBy:'u2', createdAt: now, comments: [{author:'u1', text:'Looks great!', at: now}] },
    ]);
  }
  if (!load(STORE.activity, null)) save(STORE.activity, []);
}
seed();

// Auth helpers
window.TF = {
  STORE, load, save,
  currentUser: () => {
    const s = load(STORE.session, null);
    if (!s) return null;
    return load(STORE.users, []).find(u => u.id === s.userId) || null;
  },
  signIn: (email, password) => {
    const user = load(STORE.users, []).find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (!user) throw new Error('Invalid email or password');
    save(STORE.session, { userId: user.id, at: Date.now() });
    return user;
  },
  signUp: ({ name, email, password, role }) => {
    const users = load(STORE.users, []);
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) throw new Error('Email already in use');
    const user = { id: 'u' + Date.now(), name, email, password, role: role || 'member' };
    users.push(user);
    save(STORE.users, users);
    save(STORE.session, { userId: user.id, at: Date.now() });
    return user;
  },
  signOut: () => localStorage.removeItem(STORE.session),
};

// ===== UI (only if on login page) =====
if (document.querySelector('.auth-shell')) {
  // Already signed in? jump to dashboard
  if (TF.currentUser()) location.replace('./dashboard.html');

  const tabs = document.querySelectorAll('.tab');
  const forms = { login: document.getElementById('loginForm'), signup: document.getElementById('signupForm') };
  const msg = document.getElementById('authMsg');

  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    Object.entries(forms).forEach(([k,f]) => f.classList.toggle('active', k === t.dataset.tab));
    msg.textContent = '';
  }));

  forms.login.addEventListener('submit', e => {
    e.preventDefault();
    try {
      TF.signIn(document.getElementById('loginEmail').value.trim(), document.getElementById('loginPassword').value);
      msg.className = 'auth-msg ok'; msg.textContent = 'Welcome back!';
      setTimeout(() => location.href = './dashboard.html', 400);
    } catch (err) { msg.className = 'auth-msg err'; msg.textContent = err.message; }
  });

  forms.signup.addEventListener('submit', e => {
    e.preventDefault();
    try {
      TF.signUp({
        name: document.getElementById('suName').value.trim(),
        email: document.getElementById('suEmail').value.trim(),
        password: document.getElementById('suPassword').value,
        role: document.getElementById('suRole').value,
      });
      msg.className = 'auth-msg ok'; msg.textContent = 'Account created — taking you in…';
      setTimeout(() => location.href = './dashboard.html', 500);
    } catch (err) { msg.className = 'auth-msg err'; msg.textContent = err.message; }
  });
}
