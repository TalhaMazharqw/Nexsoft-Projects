// Dashboard logic — requires auth.js loaded first... but we keep this file standalone-safe.
const S = {
  users: 'tf_users', session: 'tf_session', tasks: 'tf_tasks', activity: 'tf_activity',
};
const L = (k, f) => { try { return JSON.parse(localStorage.getItem(k)) ?? f; } catch { return f; } };
const W = (k, v) => localStorage.setItem(k, JSON.stringify(v));

const me = (() => {
  const s = L(S.session, null);
  if (!s) { location.replace('./index.html'); return null; }
  const u = L(S.users, []).find(x => x.id === s.userId);
  if (!u) { localStorage.removeItem(S.session); location.replace('./index.html'); return null; }
  return u;
})();
if (!me) throw new Error('redirect');

// Role permissions
const can = {
  delete: (task) => me.role === 'admin' || task.createdBy === me.id,
  editAny: () => me.role === 'admin' || me.role === 'manager',
  edit: (task) => can.editAny() || task.createdBy === me.id || task.assignee === me.id,
};

// State
let tasks = L(S.tasks, []);
let users = L(S.users, []);
let activity = L(S.activity, []);

const $ = (id) => document.getElementById(id);
const initials = (name) => name.split(' ').map(s => s[0]).join('').slice(0,2).toUpperCase();

function logActivity(action, taskTitle) {
  activity.unshift({ id: 'a'+Date.now()+Math.random(), userId: me.id, action, taskTitle, at: Date.now() });
  activity = activity.slice(0, 50);
  W(S.activity, activity);
}

function toast(msg) {
  const t = $('toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2200);
}

// ===== Header / me =====
$('meName').textContent = me.name;
$('meRole').textContent = me.role;
$('meAvatar').textContent = initials(me.name);
$('logoutBtn').addEventListener('click', () => {
  localStorage.removeItem(S.session);
  location.replace('./index.html');
});

// ===== Navigation =====
const views = { board:'Board', list:'List view', team:'Team', activity:'Activity' };
const subs  = {
  board:'Track tasks across status columns',
  list:'Compact spreadsheet view of every task',
  team:'People in your workspace and their workload',
  activity:'Recent changes across the project'
};
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const v = btn.dataset.view;
    document.querySelectorAll('.view').forEach(s => s.classList.remove('active'));
    $('view-' + v).classList.add('active');
    $('viewTitle').textContent = views[v];
    $('viewSub').textContent = subs[v];
    if (v === 'team') renderTeam();
    if (v === 'activity') renderActivity();
  });
});

// ===== Render board + list =====
const search = $('search');
const filterPri = $('filterPriority');
search.addEventListener('input', renderAll);
filterPri.addEventListener('change', renderAll);

function filteredTasks() {
  const q = search.value.trim().toLowerCase();
  const p = filterPri.value;
  return tasks.filter(t =>
    (!q || t.title.toLowerCase().includes(q) || (t.desc||'').toLowerCase().includes(q)) &&
    (!p || t.priority === p)
  );
}

function taskCardHTML(t) {
  const u = users.find(x => x.id === t.assignee);
  const overdue = t.due && t.status !== 'done' && new Date(t.due) < new Date(new Date().toDateString());
  return `
    <div class="card" data-id="${t.id}">
      <h4>${escapeHtml(t.title)}</h4>
      ${t.desc ? `<p>${escapeHtml(t.desc)}</p>` : ''}
      <div class="card-meta">
        <span class="pill p-${t.priority.toLowerCase()}">${t.priority}</span>
        ${u ? `<span class="avatar" style="width:24px;height:24px;font-size:.65rem" title="${escapeHtml(u.name)}">${initials(u.name)}</span>` : ''}
        ${t.due ? `<span class="due ${overdue?'overdue':''}">📅 ${t.due}</span>` : ''}
      </div>
    </div>`;
}

function renderBoard() {
  const list = filteredTasks();
  ['todo','in_progress','done'].forEach(status => {
    const items = list.filter(t => t.status === status);
    $('col-' + status).innerHTML = items.map(taskCardHTML).join('') || `<p class="muted" style="font-size:.8rem;text-align:center;padding:1rem">No tasks</p>`;
    $('count-' + status).textContent = items.length;
  });
  document.querySelectorAll('.card').forEach(c => c.addEventListener('click', () => openTaskModal(c.dataset.id)));
}

function renderList() {
  const rows = filteredTasks().map(t => {
    const u = users.find(x => x.id === t.assignee);
    return `<tr data-id="${t.id}">
      <td><b>${escapeHtml(t.title)}</b></td>
      <td>${u ? escapeHtml(u.name) : '<span class="muted">Unassigned</span>'}</td>
      <td>${statusLabel(t.status)}</td>
      <td><span class="pill p-${t.priority.toLowerCase()}">${t.priority}</span></td>
      <td>${t.due || '—'}</td>
      <td>${can.edit(t) ? '✏️' : '👁'}</td>
    </tr>`;
  }).join('');
  $('taskTableBody').innerHTML = rows || `<tr><td colspan="6" class="muted" style="text-align:center;padding:2rem">No tasks yet</td></tr>`;
  document.querySelectorAll('#taskTableBody tr[data-id]').forEach(r => r.addEventListener('click', () => openTaskModal(r.dataset.id)));
}

function renderTeam() {
  $('teamGrid').innerHTML = users.map(u => {
    const userTasks = tasks.filter(t => t.assignee === u.id);
    const done = userTasks.filter(t => t.status === 'done').length;
    return `<div class="member-card">
      <div class="avatar">${initials(u.name)}</div>
      <h4>${escapeHtml(u.name)}</h4>
      <div class="role">${u.role}</div>
      <div class="muted" style="font-size:.78rem;margin-top:.3rem">${escapeHtml(u.email)}</div>
      <div class="stats"><div><b>${userTasks.length}</b>Assigned</div><div><b>${done}</b>Done</div></div>
    </div>`;
  }).join('');
}

function renderActivity() {
  if (!activity.length) {
    $('activityFeed').innerHTML = `<li class="muted">No activity yet — create or edit a task to get started.</li>`;
    return;
  }
  $('activityFeed').innerHTML = activity.map(a => {
    const u = users.find(x => x.id === a.userId);
    return `<li>
      <span class="avatar" style="width:28px;height:28px;font-size:.7rem">${u?initials(u.name):'?'}</span>
      <span><b>${u?escapeHtml(u.name):'Someone'}</b> ${a.action} <i>"${escapeHtml(a.taskTitle)}"</i></span>
      <span class="when">${timeAgo(a.at)}</span>
    </li>`;
  }).join('');
}

function renderAll() { renderBoard(); renderList(); }
renderAll();

// ===== Modal / CRUD =====
const modal = $('modal');
$('newTaskBtn').addEventListener('click', () => openTaskModal(null));
$('closeModal').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });

function populateAssigneeSelect() {
  $('tAssignee').innerHTML = '<option value="">Unassigned</option>' +
    users.map(u => `<option value="${u.id}">${escapeHtml(u.name)} (${u.role})</option>`).join('');
}

function openTaskModal(id) {
  populateAssigneeSelect();
  const t = id ? tasks.find(x => x.id === id) : null;
  $('modalTitle').textContent = t ? (can.edit(t) ? 'Edit task' : 'View task') : 'New task';
  $('taskId').value = t?.id || '';
  $('tTitle').value = t?.title || '';
  $('tDesc').value = t?.desc || '';
  $('tStatus').value = t?.status || 'todo';
  $('tPriority').value = t?.priority || 'Medium';
  $('tAssignee').value = t?.assignee || '';
  $('tDue').value = t?.due || '';

  const editable = !t || can.edit(t);
  ['tTitle','tDesc','tStatus','tPriority','tAssignee','tDue'].forEach(i => $(i).disabled = !editable);
  $('deleteTaskBtn').hidden = !t || !can.delete(t);
  document.querySelector('#taskForm button[type=submit]').hidden = !editable;

  // comments
  $('commentsBlock').hidden = !t;
  if (t) renderComments(t);

  modal.classList.add('open');
}
function closeModal() { modal.classList.remove('open'); }

function renderComments(t) {
  $('commentsList').innerHTML = (t.comments||[]).map(c => {
    const u = users.find(x => x.id === c.author);
    return `<li><span class="author">${u?escapeHtml(u.name):'?'}</span>${escapeHtml(c.text)}<span class="time">${timeAgo(c.at)}</span></li>`;
  }).join('') || '<li class="muted" style="background:transparent;padding:.2rem 0">No comments yet.</li>';
}

$('addCommentBtn').addEventListener('click', () => {
  const id = $('taskId').value; if (!id) return;
  const text = $('commentInput').value.trim(); if (!text) return;
  const t = tasks.find(x => x.id === id);
  t.comments = t.comments || [];
  t.comments.push({ author: me.id, text, at: Date.now() });
  W(S.tasks, tasks); $('commentInput').value = '';
  renderComments(t);
  logActivity('commented on', t.title);
  toast('Comment posted');
});

$('taskForm').addEventListener('submit', e => {
  e.preventDefault();
  const id = $('taskId').value;
  const payload = {
    title: $('tTitle').value.trim(),
    desc: $('tDesc').value.trim(),
    status: $('tStatus').value,
    priority: $('tPriority').value,
    assignee: $('tAssignee').value || null,
    due: $('tDue').value || null,
  };
  if (!payload.title) return;
  if (id) {
    const t = tasks.find(x => x.id === id);
    if (!can.edit(t)) return toast('No permission to edit');
    Object.assign(t, payload);
    logActivity('updated', t.title);
    toast('Task updated');
  } else {
    const t = { id: 't'+Date.now(), ...payload, createdBy: me.id, createdAt: Date.now(), comments: [] };
    tasks.unshift(t);
    logActivity('created', t.title);
    toast('Task created');
  }
  W(S.tasks, tasks);
  closeModal(); renderAll();
});

$('deleteTaskBtn').addEventListener('click', () => {
  const id = $('taskId').value; if (!id) return;
  const t = tasks.find(x => x.id === id);
  if (!can.delete(t)) return toast('No permission to delete');
  if (!confirm(`Delete "${t.title}"?`)) return;
  tasks = tasks.filter(x => x.id !== id);
  W(S.tasks, tasks);
  logActivity('deleted', t.title);
  closeModal(); renderAll(); toast('Task deleted');
});

// ===== Utilities =====
function statusLabel(s) {
  return { todo:'<span class="pill" style="background:rgba(154,160,195,.2);color:#bcc1e0">To do</span>',
           in_progress:'<span class="pill" style="background:rgba(255,181,71,.2);color:#ffd28a">In progress</span>',
           done:'<span class="pill" style="background:rgba(61,220,151,.2);color:#7aecbf">Done</span>' }[s];
}
function escapeHtml(s) { return String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function timeAgo(t) {
  const diff = (Date.now() - t)/1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  return Math.floor(diff/86400) + 'd ago';
}

// keyboard
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
