/**
 * Tasky — Advanced File System Management & Live Metrics Engine
 */

// ── Application State Cache ──
let tasks = JSON.parse(localStorage.getItem('tasky_file_dashboard_db')) || [];
let currentFilter = 'all';

// ── DOM References ──
const dashboardFileInput = document.getElementById('dashboardFileInput');
const inputWrapper = document.getElementById('inputWrapper');
const filePlaceholder = document.getElementById('filePlaceholder');
const prioritySelect = document.getElementById('prioritySelect');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');
const filterGroup = document.getElementById('filterGroup');
const emptyState = document.getElementById('emptyState');
const itemsLeftCount = document.getElementById('itemsLeftCount');
const clearCompletedBtn = document.getElementById('clearCompletedBtn');

// Metric Counter Elements
const totalMetric = document.getElementById('totalMetric');
const doneMetric = document.getElementById('doneMetric');
const pendingMetric = document.getElementById('pendingMetric');

// ── Real-Time Dynamic Clock System ──
function initLiveClock() {
  const updateClock = () => {
    const now = new Date();
    
    // Format Calendar Date: e.g. "Tuesday, June 2"
    const dateOptions = { weekday: 'long', month: 'long', day: 'numeric' };
    document.getElementById('liveDate').textContent = now.toLocaleDateString('en-US', dateOptions);
    
    // Format Digital Time: e.g. "07:09:20 PM"
    document.getElementById('liveTime').textContent = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };
  
  updateClock();
  setInterval(updateClock, 1000);
}

// ── UI Triggers for System File Selection ──
inputWrapper.addEventListener('click', (e) => {
  // Prevent click cascading if the user is changing priorities or submitting
  if (e.target.closest('#prioritySelect') || e.target.closest('#addTaskBtn')) return;
  dashboardFileInput.click();
});

// Update input UI layout state when a file is staged from local PC
dashboardFileInput.addEventListener('change', () => {
  if (dashboardFileInput.files.length > 0) {
    filePlaceholder.textContent = dashboardFileInput.files[0].name;
    filePlaceholder.classList.add('active-file');
  } else {
    resetInputState();
  }
});

function resetInputState() {
  dashboardFileInput.value = '';
  filePlaceholder.textContent = 'Click here to choose file from PC...';
  filePlaceholder.classList.remove('active-file');
}

// ── Storage Cache State Sync ──
function synchroniseStorage() {
  localStorage.setItem('tasky_file_dashboard_db', JSON.stringify(tasks));
  calculateMetrics();
}

// ── Core Calculations Subsystem ──
function calculateMetrics() {
  const total = tasks.length;
  const done = tasks.filter(t => t.completed).length;
  const pending = total - done;

  totalMetric.textContent = total;
  doneMetric.textContent = done;
  pendingMetric.textContent = pending;
  itemsLeftCount.textContent = `${pending} item${pending !== 1 ? 's' : ''} left`;
}

// ── Render Processing Pipeline ──
function renderDashboard() {
  taskList.innerHTML = '';
  
  // Advanced Filter Routing Ledger Engine
  const filtered = tasks.filter(task => {
    if (currentFilter === 'active') return !task.completed;
    if (currentFilter === 'completed') return task.completed;
    if (['High', 'Med', 'Low'].includes(currentFilter)) return task.priority === currentFilter;
    return true; // Default 'all' logic
  });

  if (filtered.length === 0) {
    emptyState.classList.add('visible');
  } else {
    emptyState.classList.remove('visible');

    filtered.forEach(task => {
      const li = document.createElement('li');
      li.className = `task-item ${task.completed ? 'completed' : ''}`;
      li.dataset.id = task.id;

      li.innerHTML = `
        <div class="task-item-left">
          <div class="custom-checkbox" data-action="toggle"></div>
          <div class="file-details">
            <div class="file-name-row">
              <span class="task-file-name" title="${escapeHtml(task.fileName)}">${escapeHtml(task.fileName)}</span>
              <span class="priority-badge badge-${task.priority}">${task.priority}</span>
            </div>
            <span class="file-meta-data">${task.fileSize} • Staged ${task.timestamp}</span>
          </div>
        </div>
        <button class="btn-delete" data-action="delete" title="Remove Entry">🗑</button>
      `;

      taskList.appendChild(li);
    });
  }
}

// ── Functional Modifications ──
function addNewFileTask() {
  if (dashboardFileInput.files.length === 0) {
    alert('Please map a local file from your PC first by clicking the input panel space.');
    return;
  }

  const fileInstance = dashboardFileInput.files[0];
  
  // Calculate readable byte metrics
  const sizeInBytes = fileInstance.size;
  let computedSize = `${sizeInBytes} B`;
  if (sizeInBytes > 1024 * 1024) {
    computedSize = `${(sizeInBytes / (1024 * 1024)).toFixed(1)} MB`;
  } else if (sizeInBytes > 1024) {
    computedSize = `${(sizeInBytes / 1024).toFixed(1)} KB`;
  }

  const newTask = {
    id: Date.now(),
    fileName: fileInstance.name,
    fileSize: computedSize,
    priority: prioritySelect.value,
    completed: false,
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  };

  tasks.push(newTask);
  resetInputState();
  synchroniseStorage();
  renderDashboard();
}

// ── Centralised Event Routing ──
taskList.addEventListener('click', (e) => {
  const itemRow = e.target.closest('.task-item');
  if (!itemRow) return;

  const taskId = parseInt(itemRow.dataset.id);
  const actionTarget = e.target.dataset.action;

  if (actionTarget === 'delete') {
    tasks = tasks.filter(t => t.id !== taskId);
  } else if (e.target.classList.contains('custom-checkbox') || e.target.closest('.custom-checkbox')) {
    tasks = tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
  } else {
    return; // Ignore general blank cell row clicks
  }

  synchroniseStorage();
  renderDashboard();
});

// Segment Filtering Mapping Configuration Engine
filterGroup.addEventListener('click', (e) => {
  const targetBtn = e.target.closest('.filter-btn');
  if (!targetBtn) return;

  document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
  targetBtn.classList.add('active');

  currentFilter = targetBtn.dataset.filter;
  renderDashboard();
});

// Multi-Clear Core Actions Logic
clearCompletedBtn.addEventListener('click', () => {
  tasks = tasks.filter(t => !t.completed);
  synchroniseStorage();
  renderDashboard();
});

addTaskBtn.addEventListener('click', addNewFileTask);

// XSS Sanitizer Utility
function escapeHtml(str) {
  const conversionMap = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return str.replace(/[&<>"']/g, match => conversionMap[match]);
}

// ── Lifecycles Initialization Engine ──
initLiveClock();
calculateMetrics();
renderDashboard();