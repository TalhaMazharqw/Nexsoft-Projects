/**
 * CalcVibe — Calculator Application Core State Logic Engine
 */

// ── Application Memory Architecture Registers ────────
let currentInput = '0';
let previousInput = '';
let operator = null;
let justCalculated = false;
let history = [];

// ── DOM Nodes References ────────────────────────────
const resultEl = document.getElementById('result');
const expressionEl = document.getElementById('expression');
const historyList = document.getElementById('historyList');
const btnGrid = document.getElementById('btnGrid');

// ── Display Interface Refresh Pipes ──────────────────
function updateDisplay() {
  resultEl.textContent = currentInput;
  resultEl.classList.remove('error');
  
  // Auto-Shrink Font-Sizing Scaling System
  if (currentInput.length > 12) {
    resultEl.style.fontSize = '1.5rem';
  } else if (currentInput.length > 9) {
    resultEl.style.fontSize = '2.0rem';
  } else {
    resultEl.style.fontSize = '';
  }
}

// ── User Interaction Event Pipelines ─────────────────
function inputDigit(digit) {
  if (justCalculated) {
    currentInput = digit;
    justCalculated = false;
  } else if (currentInput === '0') {
    currentInput = digit;
  } else if (currentInput.length < 15) {
    currentInput += digit;
  }
  updateDisplay();
}

function inputDecimal() {
  if (justCalculated) { 
    currentInput = '0.'; 
    justCalculated = false; 
    return; 
  }
  if (!currentInput.includes('.')) {
    currentInput += '.';
  }
  updateDisplay();
}

function inputOperator(op) {
  justCalculated = false;
  if (operator && previousInput !== '') {
    calculate(true); // Sequential calculations process operations stacking silently
  }
  previousInput = currentInput;
  operator = op;
  currentInput = '0';
  expressionEl.textContent = `${formatNum(previousInput)} ${op}`;
}

// ── Calculation Evaluation Engine ───────────────────
function calculate(silent = false) {
  if (!operator || previousInput === '') return;

  const a = parseFloat(previousInput);
  const b = parseFloat(currentInput);
  let result;

  switch (operator) {
    case '+': result = a + b; break;
    case '−': case '-': result = a - b; break;
    case '×': case '*': result = a * b; break;
    case '÷': case '/':
      if (b === 0) {
        showError('Cannot divide by 0');
        return;
      }
      result = a / b; 
      break;
    default: return;
  }

  // Clear tracking floating-point binary resolution artifacts
  result = parseFloat(result.toPrecision(12));
  const expression = `${formatNum(a)} ${operator} ${formatNum(b)} =`;

  if (!silent) {
    addHistory(expression, result);
    expressionEl.textContent = expression;
    justCalculated = true;
  }

  currentInput = String(result);
  previousInput = '';
  operator = null;
  updateDisplay();
}

// ── Value Mutator Operational Tools ─────────────────
function clearAll() {
  currentInput = '0';
  previousInput = '';
  operator = null;
  justCalculated = false;
  expressionEl.textContent = '';
  updateDisplay();
}

function deleteLast() {
  if (justCalculated) { 
    clearAll(); 
    return; 
  }
  currentInput = currentInput.slice(0, -1) || '0';
  updateDisplay();
}

function toggleSign() {
  if (currentInput === '0') return;
  currentInput = currentInput.startsWith('-')
    ? currentInput.slice(1)
    : '-' + currentInput;
  updateDisplay();
}

function inputPercent() {
  currentInput = String(parseFloat(currentInput) / 100);
  updateDisplay();
}

function showError(msg) {
  resultEl.textContent = msg;
  resultEl.classList.add('error');
  setTimeout(() => { clearAll(); }, 1500);
}

// ── History Array Caching Engine ────────────────────
function addHistory(expr, result) {
  history.unshift({ expr, result });
  if (history.length > 5) history.pop(); // Keeps last 5 operations
  renderHistory();
}

function renderHistory() {
  historyList.innerHTML = history.map(h => `
    <div class="history-item">
      ${h.expr} <span class="hi-result">${formatNum(h.result)}</span>
    </div>
  `).join('');
}

function formatNum(n) {
  const num = parseFloat(n);
  if (isNaN(num)) return n;
  return Number.isInteger(num) ? num.toLocaleString() : num;
}

// ── Layout Matrix Click Distribution Core ────────────
btnGrid.addEventListener('click', (e) => {
  const target = e.target;
  if (!target.classList.contains('btn')) return;

  const val = target.dataset.val;
  const action = target.dataset.action;

  if (val) {
    if (['+', '−', '×', '÷'].includes(val)) {
      inputOperator(val);
    } else {
      inputDigit(val);
    }
  } else if (action) {
    switch (action) {
      case 'clear':       clearAll(); break;
      case 'toggle-sign': toggleSign(); break;
      case 'percent':     inputPercent(); break;
      case 'decimal':     inputDecimal(); break;
      case 'delete':      deleteLast(); break;
      case 'calculate':   calculate(); break;
    }
  }
});

// ── Hardware Desktop Key Listeners Capture Interrupts ─
document.addEventListener('keydown', e => {
  if (e.key >= '0' && e.key <= '9') inputDigit(e.key);
  else if (e.key === '.') inputDecimal();
  else if (e.key === '+') inputOperator('+');
  else if (e.key === '-') inputOperator('−');
  else if (e.key === '*') inputOperator('×');
  else if (e.key === '/') { e.preventDefault(); inputOperator('÷'); }
  else if (e.key === 'Enter' || e.key === '=') calculate();
  else if (e.key === 'Backspace') deleteLast();
  else if (e.key === 'Escape') clearAll();
  else if (e.key === '%') inputPercent();
});