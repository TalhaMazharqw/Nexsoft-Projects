// 🔑 Your active OMDb API Key integrated with spacing errors removed
const OMDB_API_KEY = '21d615b7'; 

const BASE_URL = `https://www.omdbapi.com/?apikey=${OMDB_API_KEY}`;

// Capture UI Interaction Node Handles
const searchForm = document.getElementById('search-form');
const searchInput = document.getElementById('search-input');
const moviesGrid = document.getElementById('movies-grid');
const resultsHeading = document.getElementById('results-heading');
const statusMessage = document.getElementById('status-message');

const movieModal = document.getElementById('movie-modal');
const modalDetailsBody = document.getElementById('modal-details-body');
const modalCloseBtn = document.getElementById('modal-close-btn');
const modalCloseBackdrop = document.getElementById('modal-close-backdrop');

// Pagination State Variables (Fulfills assignment criteria)
let currentSearchTerm = '';
let currentPage = 1;
let totalResultsCount = 0;
let isCurrentlyLoading = false;

// Bootstrapping Engine Hook to inject initial display content on system startup
window.addEventListener('DOMContentLoaded', () => {
    currentSearchTerm = "Batman";
    executeMovieSearchAPI(currentSearchTerm, 1, false);
});

// Primary Search Submission Router Processing Handler
searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    
    if (!query) return;
    
    currentSearchTerm = query;
    currentPage = 1; // Reset to page 1 for a brand new search
    executeMovieSearchAPI(currentSearchTerm, currentPage, false);
});

// REST Endpoint Async Operations: Fetch elements supporting pagination appending
async function executeMovieSearchAPI(searchTerm, page = 1, appendData = false) {
    isCurrentlyLoading = true;
    if (!appendData) {
        showLoadingSpinner();
        moviesGrid.innerHTML = '';
    }
    
    resultsHeading.innerText = `Search Results for: "${searchTerm}"`;

    try {
        const response = await fetch(`${BASE_URL}&s=${encodeURIComponent(searchTerm)}&page=${page}`);
        const data = await response.json();

        if (data.Response === "True") {
            hideStatusBox();
            totalResultsCount = parseInt(data.totalResults);
            renderMoviesCollectionGrid(data.Search, appendData);
        } else {
            if (!appendData) {
                showStatusError(`No matching titles found for "${searchTerm}". Try adjusting spelling parameters.`, 'fa-circle-exclamation');
                moviesGrid.innerHTML = '';
            }
        }
    } catch (error) {
        showStatusError("Network stream execution breakdown error. Verify your connection.", "fa-wifi");
    } finally {
        isCurrentlyLoading = false;
    }
}

// REST Endpoint Async Operations: Fetch Single Detail via Target ID
async function fetchDeepMovieDetails(imdbID) {
    try {
        const response = await fetch(`${BASE_URL}&i=${imdbID}&plot=full`);
        const movie = await response.json();
        
        if (movie.Response === "True") {
            renderModalDetailsView(movie);
        }
    } catch (error) {
        alert("Unable to fetch complete records for this asset tracking entry index code.");
    }
}

// Build and Inject Dynamic Output Document Card Nodes
function renderMoviesCollectionGrid(moviesList, appendData = false) {
    if (!appendData) {
        moviesGrid.innerHTML = '';
    }

    moviesList.forEach(item => {
        const mediaPoster = item.Poster !== "N/A" ? item.Poster : "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=400";
        
        const cardElement = document.createElement('div');
        cardElement.className = 'movie-card';
        cardElement.setAttribute('data-id', item.imdbID);
        
        cardElement.innerHTML = `
            <div class="poster-frame">
                <img src="${mediaPoster}" alt="${item.Title} Visual Poster Media" loading="lazy">
                <div class="card-overlay-info">
                    <span class="card-type">${item.Type}</span>
                    <span class="card-year">${item.Year}</span>
                </div>
            </div>
            <div class="movie-info-block">
                <h3 class="movie-title" title="${item.Title}">${item.Title}</h3>
            </div>
        `;

        cardElement.addEventListener('click', () => fetchDeepMovieDetails(item.imdbID));
        moviesGrid.appendChild(cardElement);
    });
}

// Infinite Scroll Event Listener (Fulfills assignment criteria)
window.addEventListener('scroll', () => {
    if (isCurrentlyLoading) return;
    
    // Check if the user has scrolled near the bottom of the page
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 600) {
        if (moviesGrid.children.length < totalResultsCount) {
            currentPage++;
            executeMovieSearchAPI(currentSearchTerm, currentPage, true);
        }
    }
});

// Build Content Layout Elements within Modal Popover Target
function renderModalDetailsView(data) {
    const detailPoster = data.Poster !== "N/A" ? data.Poster : "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=400";
    
    modalDetailsBody.innerHTML = `
        <div class="modal-poster">
            <img src="${detailPoster}" alt="${data.Title} Poster Highres">
        </div>
        <div class="modal-text-pane">
            <h2>${data.Title}</h2>
            <div class="meta-row">
                <span class="rating-pill"><i class="fa-solid fa-star"></i> ${data.imdbRating}</span>
                <span>${data.Rated}</span>
                <span>•</span>
                <span>${data.Runtime}</span>
                <span>•</span>
                <span>${data.Released}</span>
            </div>
            <div class="meta-row">
                <strong>Genres:</strong> ${data.Genre}
            </div>
            <p class="plot-summary">${data.Plot}</p>
            <div class="credit-line"><strong>Directed By:</strong> ${data.Director}</div>
            <div class="credit-line"><strong>Screenplay Authors:</strong> ${data.Writer}</div>
            <div class="credit-line"><strong>Featured Cast :</strong> ${data.Actors}</div>
            <div class="credit-line"><strong>Box Office / Revenue:</strong> ${data.BoxOffice || "Insufficient Metrics Record Data"}</div>
        </div>
    `;
    
    movieModal.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; 
}

function showLoadingSpinner() {
    statusMessage.innerHTML = `<i class="fa-solid fa-spinner fa-spin-pulse" style="color: var(--accent-glow)"></i> Synchronizing database records pipeline stream vectors...`;
    statusMessage.classList.remove('hidden');
}

function showStatusError(message, iconClass) {
    statusMessage.innerHTML = `<i class="fa-solid ${iconClass}"></i> ${message}`;
    statusMessage.classList.remove('hidden');
}

function hideStatusBox() { statusMessage.classList.add('hidden'); }

const dropModalViewClosure = () => {
    movieModal.classList.add('hidden');
    document.body.style.overflow = ''; 
};

modalCloseBtn.addEventListener('click', dropModalViewClosure);
modalCloseBackdrop.addEventListener('click', dropModalViewClosure);

document.addEventListener('keydown', (e) => {
    if (e.key === "Escape" && !movieModal.classList.contains('hidden')) {
        dropModalViewClosure();
    }
});