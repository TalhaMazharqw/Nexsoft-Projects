// Local Persistence Data Layer (Simulating MongoDB Document Datastore)
let ledgerTransactionsCollection = JSON.parse(localStorage.getItem('mock_mongodb_expenses')) || [];

const transactionForm = document.getElementById('ledger-transaction-form');
const txDescriptionInput = document.getElementById('tx-description');
const txAmountInput = document.getElementById('tx-amount');
const txCategoryInput = document.getElementById('tx-category');
const ledgerStreamTarget = document.getElementById('ledger-stream-target');

const netBalanceValue = document.getElementById('net-balance-value');
const inflowValue = document.getElementById('inflow-value');
const outflowValue = document.getElementById('outflow-value');
const clearLedgerBtn = document.getElementById('clear-ledger-btn');

// Form Submit Handler
transactionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const description = txDescriptionInput.value.trim();
    const amount = parseFloat(txAmountInput.value);
    const category = txCategoryInput.value;
    
    if(!description || isNaN(amount)) return;

    // Document compilation model structures targeting local collection insertion matching DB schema
    const transactionDocument = {
        _id: 'tx_doc_' + Math.random().toString(36).substr(2, 9),
        description,
        amount,
        category,
        timestamp: new Date().toLocaleString()
    };

    ledgerTransactionsCollection.push(transactionDocument);
    commitAndRefreshLedger();
    transactionForm.reset();
});

// Structural Ledger Balance Calculations Parser Engine Loop
function calculateMetricsPipeline() {
    let totalInflowCalculated = 0;
    let totalOutflowCalculated = 0;

    ledgerTransactionsCollection.forEach(doc => {
        if(doc.amount > 0) {
            totalInflowCalculated += doc.amount;
        } else {
            totalOutflowCalculated += doc.amount; // Adds directly since it's already a negative number
        }
    });

    const netPoolValue = totalInflowCalculated + totalOutflowCalculated;

    // Direct interface state text inject mappings updates execution
    netBalanceValue.innerText = `$${netPoolValue.toFixed(2)}`;
    inflowValue.innerText = `+$${totalInflowCalculated.toFixed(2)}`;
    outflowValue.innerText = `-$${Math.abs(totalOutflowCalculated).toFixed(2)}`;
}

// Render Engine: Generates rows dynamically
function renderLedgerStreamView() {
    ledgerStreamTarget.innerHTML = '';

    if(ledgerTransactionsCollection.length === 0) {
        ledgerStreamTarget.innerHTML = '<p style="text-align:center; color:#64748b; padding:2rem; font-size:0.9rem;">No data documents active in standard data streams.</p>';
        return;
    }

    // Mirror collection order mapping sequences
    [...ledgerTransactionsCollection].reverse().forEach(doc => {
        const rowNode = document.createElement('div');
        const isIncome = doc.amount > 0;
        rowNode.className = `tx-ledger-row ${isIncome ? 'income-style' : 'expense-style'}`;

        rowNode.innerHTML = `
            <div class="tx-details-block">
                <h5>${doc.description}</h5>
                <span>${doc.category} • ${doc.timestamp}</span>
            </div>
            <div class="tx-numeric-actions">
                <span class="tx-value-display">${isIncome ? '+' : ''}${doc.amount.toFixed(2)}</span>
                <button class="btn-drop-tx-node" onclick="dropTransactionDocument('${doc._id}')"><i class="fa-solid fa-xmark"></i></button>
            </div>
        `;
        ledgerStreamTarget.appendChild(rowNode);
    });
}

// Single Document Deletion Target Operational Logic Route Callback Mapping
window.dropTransactionDocument = function(documentID) {
    ledgerTransactionsCollection = ledgerTransactionsCollection.filter(doc => doc._id !== documentID);
    commitAndRefreshLedger();
};

// Global Purge Loop Operational Controls Trigger
clearLedgerBtn.addEventListener('click', () => {
    if(confirm("Confirm action drop processing order request? Proceeding deletes entire mock dataset.")) {
        ledgerTransactionsCollection = [];
        commitAndRefreshLedger();
    }
});

function commitAndRefreshLedger() {
    localStorage.setItem('mock_mongodb_expenses', JSON.stringify(ledgerTransactionsCollection));
    calculateMetricsPipeline();
    renderLedgerStreamView();
}

// Application Mount Cycle Hook Run Execution
document.addEventListener('DOMContentLoaded', () => {
    calculateMetricsPipeline();
    renderLedgerStreamView();
});